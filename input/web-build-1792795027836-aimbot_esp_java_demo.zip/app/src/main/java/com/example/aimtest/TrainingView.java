package com.example.aimtest;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TrainingView extends View {
    private static class Target {
        float x, y, vx, vy, radius;
        Target(float x, float y, float vx, float vy, float radius) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.radius=radius;
        }
    }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Target> targets = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private boolean aimLite=true, esp=true, running=true;
    private float crossX, crossY;
    private int score=0;

    private final Runnable frame = new Runnable() {
        @Override public void run() {
            if (!running) return;
            updateTargets();
            invalidate();
            handler.postDelayed(this, 16);
        }
    };

    public TrainingView(Context c) { super(c); setBackgroundColor(Color.rgb(8,12,18)); }
    public boolean isAimLite(){ return aimLite; }
    public boolean isEsp(){ return esp; }
    public void setAimLite(boolean b){ aimLite=b; invalidate(); }
    public void setEsp(boolean b){ esp=b; invalidate(); }
    public void startAnimation(){ running=true; handler.removeCallbacks(frame); handler.post(frame); }
    public void stopAnimation(){ running=false; handler.removeCallbacks(frame); }

    private void ensureTargets() {
        if (!targets.isEmpty() || getWidth()<=0 || getHeight()<=0) return;
        for(int i=0;i<5;i++){
            float x=70+random.nextFloat()*Math.max(1,getWidth()-140);
            float y=90+random.nextFloat()*Math.max(1,getHeight()-180);
            targets.add(new Target(x,y,(random.nextFloat()*2-1)*2.2f,
                (random.nextFloat()*2-1)*1.8f,18+random.nextFloat()*7));
        }
        crossX=getWidth()/2f; crossY=getHeight()/2f;
    }
    private void updateTargets(){
        ensureTargets();
        for(Target t:targets){
            t.x+=t.vx; t.y+=t.vy;
            if(t.x<35||t.x>getWidth()-35)t.vx*=-1;
            if(t.y<45||t.y>getHeight()-45)t.vy*=-1;
        }
        if(aimLite&&!targets.isEmpty()){
            Target nearest=null; float best=Float.MAX_VALUE;
            for(Target t:targets){
                float dx=t.x-crossX,dy=t.y-crossY,d=dx*dx+dy*dy;
                if(d<best){best=d;nearest=t;}
            }
            if(nearest!=null){crossX+=(nearest.x-crossX)*0.075f;crossY+=(nearest.y-crossY)*0.075f;}
        }
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c); ensureTargets();
        p.setColor(Color.rgb(25,34,45)); p.setStrokeWidth(1);
        for(int x=0;x<getWidth();x+=48)c.drawLine(x,0,x,getHeight(),p);
        for(int y=0;y<getHeight();y+=48)c.drawLine(0,y,getWidth(),y,p);

        for(int i=0;i<targets.size();i++){
            Target t=targets.get(i);
            if(esp){
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(Color.rgb(60,255,130));
                c.drawRoundRect(new RectF(t.x-28,t.y-38,t.x+28,t.y+38),5,5,p);
                p.setStyle(Paint.Style.FILL); p.setTextSize(13); p.setColor(Color.WHITE);
                c.drawText("ALVO "+(i+1),t.x-26,t.y-45,p);
                float d=(float)Math.hypot(t.x-getWidth()/2f,t.y-getHeight()/2f);
                c.drawText((int)(d/10)+" m*",t.x-18,t.y+54,p);
            }
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(255,90,90)); c.drawCircle(t.x,t.y,t.radius,p);
            p.setColor(Color.WHITE); c.drawCircle(t.x,t.y,4,p);
        }
        p.setColor(aimLite?Color.CYAN:Color.WHITE); p.setStrokeWidth(3); p.setStyle(Paint.Style.STROKE);
        c.drawCircle(crossX,crossY,16,p);
        c.drawLine(crossX-25,crossY,crossX-7,crossY,p); c.drawLine(crossX+7,crossY,crossX+25,crossY,p);
        c.drawLine(crossX,crossY-25,crossX,crossY-7,p); c.drawLine(crossX,crossY+7,crossX,crossY+25,p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextSize(16); c.drawText("Pontos: "+score,12,24,p);
        p.setTextSize(11); p.setColor(Color.LTGRAY); c.drawText("* distância ilustrativa",12,getHeight()-12,p);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            ensureTargets();
            for(int i=targets.size()-1;i>=0;i--){
                Target t=targets.get(i); float dx=e.getX()-t.x,dy=e.getY()-t.y;
                if(dx*dx+dy*dy<=(t.radius+18)*(t.radius+18)){
                    score++; t.x=40+random.nextFloat()*Math.max(1,getWidth()-80);
                    t.y=55+random.nextFloat()*Math.max(1,getHeight()-110); invalidate(); return true;
                }
            }
            crossX=e.getX(); crossY=e.getY(); invalidate(); return true;
        }
        return true;
    }
}
