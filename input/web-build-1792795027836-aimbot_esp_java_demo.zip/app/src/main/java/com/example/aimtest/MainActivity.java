package com.example.aimtest;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TrainingView trainingView;
    private Button aimButton, espButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 12, 16, 12);
        root.setBackgroundColor(Color.rgb(18, 22, 30));

        TextView title = new TextView(this);
        title.setText("AIM TEST • TREINAMENTO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        title.setPadding(4, 8, 4, 12);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        aimButton = new Button(this); aimButton.setText("AIM LITE: ON");
        espButton = new Button(this); espButton.setText("ESP: ON");
        controls.addView(aimButton, new LinearLayout.LayoutParams(0, -2, 1));
        controls.addView(espButton, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(controls);

        TextView hint = new TextView(this);
        hint.setText("Toque nos alvos para marcar pontos. Alvos e indicadores são fictícios.");
        hint.setTextColor(Color.LTGRAY); hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER); hint.setPadding(4, 4, 4, 8);
        root.addView(hint);

        trainingView = new TrainingView(this);
        root.addView(trainingView, new LinearLayout.LayoutParams(-1, 0, 1));

        aimButton.setOnClickListener(v -> {
            trainingView.setAimLite(!trainingView.isAimLite());
            aimButton.setText(trainingView.isAimLite() ? "AIM LITE: ON" : "AIM LITE: OFF");
        });
        espButton.setOnClickListener(v -> {
            trainingView.setEsp(!trainingView.isEsp());
            espButton.setText(trainingView.isEsp() ? "ESP: ON" : "ESP: OFF");
        });
        setContentView(root);
    }

    @Override protected void onPause() {
        super.onPause();
        if (trainingView != null) trainingView.stopAnimation();
    }
    @Override protected void onResume() {
        super.onResume();
        if (trainingView != null) trainingView.startAnimation();
    }
}
