# Aim Test Demo (Java / Android)

Demonstração educacional de treinamento dentro do próprio aplicativo:
- Aimbot Lite simulado: a mira acompanha suavemente o alvo fictício mais próximo.
- ESP simulado: caixas e distâncias ilustrativas para alvos criados pelo app.
- Toque nos alvos para marcar pontos.
- Botões para ligar/desligar os dois recursos.

## Abrir
1. Extraia o ZIP.
2. Abra a pasta no Android Studio.
3. Aguarde o Gradle Sync.
4. Use Build > Build APK(s).

Requisitos: Android Studio recente, JDK configurado e Android SDK 35 instalado (ou ajuste `compileSdk` para uma versão disponível).

Este projeto funciona apenas no próprio app. Não interage com Free Fire, não injeta código e não lê a memória de outros processos.
