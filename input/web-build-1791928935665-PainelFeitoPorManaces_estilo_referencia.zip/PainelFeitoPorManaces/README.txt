PAINEL FEITO POR MANACES — projeto inicial Android Studio

Como abrir:
1. Extraia este ZIP.
2. Abra a pasta PainelFeitoPorManaces no Android Studio.
3. Aguarde o Gradle sincronizar.
4. Use Build > Build APK(s).

Incluído:
- Interface inspirada na referência enviada, com botões reais na interface.
- Botão para tentar abrir Free Fire normal e, como alternativa, Free Fire MAX.
- Gerador de sugestões de sensibilidade.
- Seleção visual de DPI; não altera o DPI do sistema.
- Atalho para a permissão Android de sobreposição.
- Botão de cor e botão de modo visual apenas.

Limitações importantes:
- Este ZIP contém o projeto-fonte, não um APK já compilado.
- A janela flutuante real ainda não foi implementada.
- Aplicação de DPI via Shizuku ainda não está implementada.
- O botão "xit" é somente visual e não injeta nada no jogo.
- O Gradle pode precisar baixar componentes pela internet na primeira compilação.
