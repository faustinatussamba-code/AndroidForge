package com.painelff.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int RED = Color.rgb(255, 25, 55);
    private final int BG = Color.rgb(8, 9, 11);
    private final int CARD = Color.rgb(18, 20, 23);
    private LinearLayout root;
    private int colorIndex = 0;
    private final int[] accentColors = {0xFFFF1937, 0xFF00D878, 0xFF168BFF, 0xFFFFC400, 0xFF9B59FF};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(16));
        d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void addGap(LinearLayout l, int h) {
        View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private Button action(String title, Runnable r) {
        Button b = new Button(this); b.setText(title); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(shape(RED, 0xFFFF526A)); b.setPadding(dp(8), dp(4), dp(8), dp(4));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.topMargin = dp(8); return addButtonToCurrent(b,p);
    }
    private Button addButtonToCurrent(Button b, LinearLayout.LayoutParams p) {
        // button is added by caller to avoid hidden global layout state
        return b;
    }
    private void addAction(LinearLayout parent, String title, Runnable r) {
        Button b = action(title,r); parent.addView(b,new LinearLayout.LayoutParams(-1,dp(50)) {{
            topMargin=dp(8);
        }});
    }
    private LinearLayout card() {
        LinearLayout c=column(); c.setPadding(dp(15),dp(14),dp(15),dp(14));
        c.setBackground(shape(CARD,0xFF64202B)); return c;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = column(); root.setPadding(dp(16),dp(10),dp(16),dp(20)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        TextView brand=label("🔥  PAINEL FEITO POR",20,Color.WHITE,true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand,new LinearLayout.LayoutParams(-1,dp(40)));
        TextView manaces=label("MANACES",34,RED,true); manaces.setGravity(Gravity.CENTER);
        root.addView(manaces,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView tagline=label("SENSIBILIDADE  •  DPI  •  TREINO",12,0xFFB7BBC4,true);
        tagline.setGravity(Gravity.CENTER); root.addView(tagline);
        addGap(root,12);

        ImageView hero = new ImageView(this);
        hero.setImageResource(R.drawable.painel_manaces_concept);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.setBackground(shape(BG,RED)); hero.setClipToOutline(true);
        root.addView(hero,new LinearLayout.LayoutParams(-1,dp(178)));
        addGap(root,12);

        LinearLayout launchCard=card();
        launchCard.addView(label("ACESSO RÁPIDO",16,Color.WHITE,true));
        addAction(launchCard,"▶  ABRIR FREE FIRE",this::openFreeFire);
        root.addView(launchCard); addGap(root,10);

        LinearLayout sens=card();
        sens.addView(label("✥  GERADOR DE SENSIBILIDADE",17,0xFFFF526A,true));
        sens.addView(label("Sugestão inicial para ajustar no treino.",13,0xFFB7BBC4,false));
        addAction(sens,"GERAR SENSIBILIDADE",()->new AlertDialog.Builder(this)
            .setTitle("Sensibilidade — Manaces")
            .setMessage("Geral 92\\nPonto vermelho 85\\nMira 2x 75\\nMira 4x 65\\nMira AWM 50\\nOlhadinha 80\\n\\nUse como ponto de partida e ajuste no treino.")
            .setPositiveButton("FECHAR",null).show());
        root.addView(sens); addGap(root,10);

        LinearLayout dpi=card();
        dpi.addView(label("▣  DPI (SHIZUKU)",17,0xFFFF526A,true));
        dpi.addView(label("Consulte a densidade e verifique o Shizuku.",13,0xFFB7BBC4,false));
        addAction(dpi,"CONFIGURAR DPI",this::showDpiDialog);
        root.addView(dpi); addGap(root,10);

        LinearLayout tools=card();
        tools.addView(label("⚒  FERRAMENTAS",17,0xFFFF526A,true));
        addAction(tools,"ATIVAR XIT (APENAS VISUAL)",()->new AlertDialog.Builder(this)
            .setTitle("Demonstração visual").setMessage("Este botão é apenas demonstrativo e não altera o Free Fire.")
            .setPositiveButton("OK",null).show());
        addAction(tools,"INICIAR PAINEL FLUTUANTE",this::startFloating);
        addAction(tools,"MUDAR COR DO PAINEL",()->{
            colorIndex=(colorIndex+1)%accentColors.length;
            manaces.setTextColor(accentColors[colorIndex]);
            Toast.makeText(this,"Tema atualizado.",Toast.LENGTH_SHORT).show();
        });
        root.addView(tools); addGap(root,14);

        TextView footer=label("PAINEL FEITO POR MANACES  •  V1.2",11,0xFF858A94,true);
        footer.setGravity(Gravity.CENTER); root.addView(footer);
    }

    private void showDpiDialog() {
        DisplayMetrics metrics=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        LinearLayout box=column(); box.setPadding(dp(8),dp(6),dp(8),dp(4));
        box.addView(label("Densidade atual informada: "+metrics.densityDpi+" DPI",15,Color.WHITE,true));
        EditText input=new EditText(this); input.setSingleLine(true); input.setInputType(2);
        input.setText("700"); input.setHint("DPI desejado"); box.addView(input);
        box.addView(label("A aplicação automática por Shizuku ainda exige integração autorizada; esta tela não altera o DPI sozinha.",12,0xFFB7BBC4,false));
        new AlertDialog.Builder(this).setTitle("DPI manual").setView(box)
            .setNegativeButton("Cancelar",null)
            .setNeutralButton("Configurações de tela",(d,w)->{
                try { startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); }
                catch(Exception e){ Toast.makeText(this,"Abra Configurações > Tela.",Toast.LENGTH_LONG).show(); }
            })
            .setPositiveButton("Verificar Shizuku",(d,w)->{
                try {
                    int value=Integer.parseInt(input.getText().toString().trim());
                    if(value<100||value>1000) throw new NumberFormatException();
                    boolean installed;
                    try { getPackageManager().getPackageInfo("moe.shizuku.privileged.api",0); installed=true; }
                    catch(Exception ex){ installed=false; }
                    String msg=(installed?"Shizuku instalado. ":"Shizuku não encontrado. ")+"Valor escolhido: "+value+" DPI. A aplicação automática não está habilitada nesta versão.";
                    new AlertDialog.Builder(this).setTitle("Estado do Shizuku").setMessage(msg).setPositiveButton("OK",null).show();
                } catch(Exception e){ Toast.makeText(this,"Digite um DPI entre 100 e 1000.",Toast.LENGTH_LONG).show(); }
            }).show();
    }
    private void openFreeFire() {
        Intent i=getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if(i==null) Toast.makeText(this,"Free Fire normal não encontrado.",Toast.LENGTH_LONG).show();
        else startActivity(i);
    }
    private void startFloating() {
        if(!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
            Toast.makeText(this,"Autorize sobreposição e toque novamente.",Toast.LENGTH_LONG).show(); return;
        }
        startService(new Intent(this,FloatingPanelService.class));
        Toast.makeText(this,"Painel flutuante iniciado.",Toast.LENGTH_SHORT).show();
    }
}
