# Painel feito por Manaces — Android

Atualização visual v1.2:
- Tema escuro com bordas e botões vermelhos.
- Marca “Painel feito por Manaces”.
- Arte conceitual incluída como banner dentro do app.
- Atalhos para Free Fire, gerador de sensibilidade, DPI/Shizuku e painel flutuante.

A arte é usada como banner visual; os controles são componentes Android reais separados da imagem. A aplicação efetiva do DPI via Shizuku ainda não está implementada. Este ZIP contém código-fonte, não APK compilado.

Abra a pasta no Android Studio, sincronize Gradle e use Build > Build APK(s).
