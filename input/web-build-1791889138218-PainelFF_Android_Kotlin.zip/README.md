# Painel FF — projeto inicial Kotlin

Inclui tema automático azul, verde, vermelho, preto e amarelo; campo de DPI padrão 700; verificação/autorização do Shizuku; leitura, aplicação manual e restauração do DPI capturado; botão para abrir o Free Fire normal.

## Compilar
Abra a pasta no Android Studio ou ambiente compatível com Gradle e compile o módulo `app`.

## Atenção
- Projeto-base, ainda precisa ser compilado e testado em aparelho real.
- Inicie o Shizuku e autorize o Painel FF.
- O DPI afeta a interface inteira do Android.
- Leia o DPI antes de aplicar. O valor original fica guardado apenas enquanto o app está aberto.
- Não injeta sensibilidade no Free Fire nem modifica arquivos internos do jogo.
