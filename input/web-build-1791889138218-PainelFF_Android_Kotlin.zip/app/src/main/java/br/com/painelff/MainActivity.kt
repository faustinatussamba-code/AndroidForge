package br.com.painelff

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var current: TextView
    private lateinit var dpiInput: EditText
    private var originalDpi: Int? = null

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            status.text = if (result == android.content.pm.PackageManager.PERMISSION_GRANTED)
                "Shizuku autorizado" else "Permissão Shizuku negada"
            if (result == android.content.pm.PackageManager.PERMISSION_GRANTED) readDpi()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        buildUi()
        refreshStatus()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(14, 14, 20))
        }
        fun label(value: String, size: Float = 16f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 8)
        }
        layout.addView(label("🔥 PAINEL FF", 26f))
        layout.addView(label("DPI manual • Shizuku • Tema automático"))
        status = label("Verificando Shizuku…")
        layout.addView(status)
        current = label("DPI atual: ainda não lido")
        layout.addView(current)
        dpiInput = EditText(this).apply {
            hint = "DPI desejado (ex.: 700)"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            setSingleLine(true); setText("700")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(dpiInput, LinearLayout.LayoutParams(-1, -2))
        layout.addView(makeButton("Verificar / autorizar Shizuku") {
            if (!Shizuku.pingBinder()) status.text = "Abra o Shizuku e inicie o serviço."
            else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                status.text = "Shizuku autorizado"; readDpi()
            } else Shizuku.requestPermission(1001)
        })
        layout.addView(makeButton("Ler DPI atual") { readDpi() })
        layout.addView(makeButton("APLICAR DPI") {
            val value = dpiInput.text.toString().toIntOrNull()
            if (value == null || value !in 100..1000) status.text = "Informe um DPI entre 100 e 1000."
            else confirmApply(value, "DPI $value")
        })
        layout.addView(makeButton("RESTAURAR DPI ORIGINAL") {
            val saved = originalDpi
            if (saved == null) status.text = "Leia o DPI atual primeiro para guardar o original."
            else confirmApply(saved, "DPI original ($saved)")
        })
        layout.addView(makeButton("Abrir Free Fire") {
            val launch = packageManager.getLaunchIntentForPackage("com.dts.freefireth")
            if (launch != null) startActivity(launch)
            else status.text = "Free Fire normal não encontrado."
        })
        layout.addView(label("Tema alterna: azul, verde, vermelho, preto e amarelo.", 12f))
        setContentView(ScrollView(this).apply { addView(layout) })
        startThemeCycle(layout)
    }

    private fun makeButton(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 7, 0, 7) }
    }

    private fun refreshStatus() {
        status.text = when {
            !Shizuku.pingBinder() -> "Shizuku não iniciado"
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED -> "Shizuku autorizado"
            else -> "Shizuku iniciado; autorização necessária"
        }
    }

    private fun confirmApply(value: Int, description: String) {
        android.app.AlertDialog.Builder(this).setTitle("Confirmar alteração")
            .setMessage("Aplicar $description ao Android inteiro? Isso pode alterar o tamanho da interface.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Aplicar") { _, _ -> applyDpi(value) }.show()
    }

    private fun readDpi() {
        if (!hasShizuku()) return
        executor.execute {
            val output = runCommand("wm density")
            val numbers = Regex("(?:Physical|Override) density:\\s*(\\d+)").findAll(output)
                .mapNotNull { it.groupValues[1].toIntOrNull() }.toList()
            runOnUiThread {
                if (numbers.isNotEmpty()) {
                    val effective = numbers.last()
                    if (originalDpi == null) originalDpi = effective
                    current.text = "DPI lido: $effective • Original salvo: $originalDpi"
                    status.text = "Leitura concluída"
                } else status.text = "Não foi possível ler o DPI: $output"
            }
        }
    }

    private fun applyDpi(value: Int) {
        if (!hasShizuku()) return
        executor.execute {
            val commandResult = runCommand("wm density $value")
            val verify = runCommand("wm density")
            runOnUiThread {
                current.text = verify
                status.text = if (verify.contains("Override density: $value"))
                    "Alteração confirmada: $value DPI"
                else "Não foi possível confirmar. $commandResult"
            }
        }
    }

    private fun hasShizuku(): Boolean {
        if (!Shizuku.pingBinder()) {
            status.text = "Inicie o serviço no Shizuku."
            return false
        }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            status.text = "Autorize o Painel FF no Shizuku."
            Shizuku.requestPermission(1001)
            return false
        }
        return true
    }

    private fun runCommand(command: String): String = try {
        val process = Shizuku.newProcess(command.split(" ").toTypedArray(), null, null)
        val out = BufferedReader(InputStreamReader(process.inputStream)).readText()
        val err = BufferedReader(InputStreamReader(process.errorStream)).readText()
        process.waitFor()
        (out + "\n" + err).trim()
    } catch (e: Exception) { "Erro: ${e.message}" }

    private fun startThemeCycle(root: View) {
        val colors = intArrayOf(
            Color.rgb(15, 40, 100), Color.rgb(15, 90, 45),
            Color.rgb(110, 15, 25), Color.rgb(14, 14, 20),
            Color.rgb(105, 85, 0)
        )
        val handler = android.os.Handler(mainLooper)
        var index = 0
        val task = object : Runnable {
            override fun run() {
                root.setBackgroundColor(colors[index % colors.size])
                index++
                handler.postDelayed(this, 2500)
            }
        }
        handler.post(task)
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        executor.shutdownNow()
        super.onDestroy()
    }
}
