# ShadowBoost Safe — projeto Android Studio

Esta é uma base de aplicativo com botão **APLICAR AJUSTES**. Por segurança e pelas limitações do Android, o botão mostra um plano de ajustes e não força FPS, DPI, escala de renderização ou comandos ADB. Ele não modifica os arquivos do Free Fire e não solicita permissões especiais.

## Abrir
1. Extraia o ZIP.
2. Abra a pasta no Android Studio ou em um ambiente Android compatível.
3. Aguarde a sincronização do Gradle e compile o projeto.
4. Instale o APK gerado no aparelho de teste.

## Importante
Este arquivo é código-fonte, não um APK compilado. A aplicação não aplica automaticamente ajustes de desempenho; os ajustes precisam ser feitos nas configurações do jogo/sistema conforme as opções disponíveis.
