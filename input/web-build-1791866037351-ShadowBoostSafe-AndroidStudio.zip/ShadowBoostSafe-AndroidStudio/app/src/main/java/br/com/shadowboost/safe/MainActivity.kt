package br.com.shadowboost.safe

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(17, 22, 32)
    private val panel = Color.rgb(29, 37, 51)
    private val accent = Color.rgb(94, 184, 255)
    private val white = Color.rgb(242, 246, 252)
    private val muted = Color.rgb(183, 194, 209)
    private var applied = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("SHADOWBOOST SAFE", 25, accent, true))
        root.addView(text("Samsung Galaxy A07 • painel de recomendações", 14, muted, false))
        root.addView(space(18))
        root.addView(card(
            "O que este botão faz",
            "O Android não permite que um app comum force FPS, DPI ou escala global de renderização sem acesso especial. Este botão abre as configurações relevantes e mostra um plano seguro; não executa comandos ocultos nem modifica o Free Fire."
        ))
        root.addView(space(14))
        root.addView(text("Ajustes seguros", 19, white, true))
        root.addView(space(8))
        root.addView(card(
            "Antes de jogar",
            "• Feche gravação de tela e apps pesados.\n• Deixe o aparelho esfriar se estiver quente.\n• No Free Fire, use gráficos Suave e escolha uma taxa de FPS estável disponível.\n• Mantenha a escala de renderização do Android no padrão."
        ))
        root.addView(space(10))
        root.addView(card(
            "Nota sobre o A07",
            "A tela pode suportar até 90 Hz, mas isso não garante que o Free Fire rode a 90 FPS. O jogo, o sistema e a temperatura determinam o desempenho real."
        ))
        root.addView(space(14))

        val apply = Button(this).apply {
            text = "APLICAR AJUSTES"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(43, 109, 165))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
            )
            setOnClickListener { applySafeAdjustments() }
        }
        root.addView(apply)
        root.addView(space(10))

        val settings = Button(this).apply {
            text = "ABRIR CONFIGURAÇÕES DE TELA"
            textSize = 14f
            isAllCaps = false
            setTextColor(white)
            setBackgroundColor(panel)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
            )
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
        }
        root.addView(settings)
        root.addView(space(16))
        root.addView(text(
            "Estado: ${if (applied) "orientações exibidas" else "aguardando ação"}\n" +
            "Este projeto não aumenta FPS por conta própria e não altera arquivos do jogo.",
            13, muted, false
        ))
    }

    private fun applySafeAdjustments() {
        applied = true
        Toast.makeText(
            this,
            "Ajustes seguros: siga as recomendações exibidas e confira as opções do jogo.",
            Toast.LENGTH_LONG
        ).show()

        val info = "AJUSTES PARA TESTAR\n\n" +
            "1. Free Fire: Gráficos Suave.\n" +
            "2. FPS: escolha uma opção estável disponível no jogo.\n" +
            "3. Feche gravador de tela e apps pesados.\n" +
            "4. Evite jogar com o telefone quente.\n" +
            "5. Não force DPI ou escala de renderização.\n\n" +
            "Nenhuma configuração do jogo ou do sistema foi alterada automaticamente."
        val view = TextView(this).apply {
            text = info
            textSize = 16f
            setTextColor(white)
            setPadding(dp(20), dp(20), dp(20), dp(20))
            setBackgroundColor(panel)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Plano de ajustes seguros")
            .setView(view)
            .setPositiveButton("Entendi", null)
            .show()
    }

    private fun card(title: String, body: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(panel)
            addView(text(title, 16, white, true))
            addView(space(6))
            addView(text(body, 14, muted, false))
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView {
        return TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.START
            setLineSpacing(dp(2).toFloat(), 1.0f)
        }
    }

    private fun space(height: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
