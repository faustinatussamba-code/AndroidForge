# Welcome to X-AIM !

## The open-source crosshair program en enhance your best Windows FPS games

The purpose of this program is to enhance the aiming and targeting experience in first-person shooter (FPS) games.
It provides a crosshair overlay on the screen, which helps players to precisely aim at their targets and improve their accuracy.
By using this application, players can have better control over their shots, leading to more successful hits and potentially increasing their overall performance in the game.

# USAGE

X-AIM is simple to use. Just launch the program, and a crosshair appears on your screen.
You can change the crosshair shape by using the wheel mouse, or key arrow left or right.
You can move the cross hair by dragging in with the mous, or by using SHIFT + arrow keys (make the crosshair move pixel per pixel).
To exit X-AIM, press ESCAPE or ALT+F4
Press F1 key to display an help screen.

Start your best FPS game, let's say Fortnite for example. Set the game to be windowed mode, and use the ALT+TAB or Windows key to birng X-AIM to the front.

Note that crosshairs are simple PNG file. You can design your own if you want. Maximum size is 32x32, 8bits color depths. Pure white color will be transparent. Image is streteched to 32x32.

# LICENCE

This program and its source code are copyleft https://unlicense.org.
https://github.com/psa-jforestier/x-aim
Pleasently bring you by JayRom95.fr

