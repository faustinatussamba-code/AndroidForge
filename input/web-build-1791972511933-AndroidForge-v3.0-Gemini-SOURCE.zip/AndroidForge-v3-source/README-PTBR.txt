ANDROIDFORGE V3.0 — PACOTE-FONTE COM ASSISTENTE GEMINI
=====================================================

O QUE ESTE ZIP CONTÉM
- assets/index.html: interface AndroidForge com painel de IA Gemini adicionado.
- Este é um pacote de FONTE/ASSETS para integração no projeto Android. Não é um APK compilado e não atualiza automaticamente o APK existente.

COMO TESTAR
1. Abra assets/index.html em um navegador compatível com JavaScript e conexão à internet.
2. No painel “ANDROIDFORGE AI • GEMINI”, cole sua própria Gemini API Key no campo da tela.
3. Escreva uma pergunta e toque em “PERGUNTAR À IA”.

INTEGRAÇÃO NO PROJETO ANDROID
- Substitua o arquivo assets/index.html do projeto pelo arquivo deste pacote.
- Confirme que o AndroidManifest.xml do projeto tem a permissão android.permission.INTERNET.
- A WebView deve permitir JavaScript e acesso HTTPS.
- Compile e assine novamente o projeto usando o projeto Android original.

SEGURANÇA DA API KEY
- A chave NÃO está incluída neste ZIP nem gravada no código.
- Não publique APKs com uma chave de API embutida. Para distribuir o app, o recomendado é criar um backend que mantenha a chave em segredo e encaminhe as solicitações.
- Como uma chave foi compartilhada na conversa, se ela era uma chave real e completa, revogue-a/rotacione-a no painel do Google AI Studio e gere outra.
- O código chama o endpoint Gemini API com o modelo gemini-2.5-flash. A disponibilidade depende da sua conta, região, cota e estado atual da API.

LIMITAÇÕES
- A IA responde perguntas; ela não consegue alterar diretamente DPI, taxa de atualização, RAM ou configurações do sistema.
- A chamada direta do navegador para a API é apenas para teste local; não é a arquitetura recomendada para distribuir o aplicativo.
