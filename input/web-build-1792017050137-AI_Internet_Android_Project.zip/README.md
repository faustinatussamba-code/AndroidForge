# Projeto Android: IA + acesso à internet

Este é um projeto-base Android Studio em Kotlin. O manifesto inclui a permissão `android.permission.INTERNET` e o app contém uma interface simples de conversa.

## O que está incluído
- `AndroidManifest.xml` com permissão de internet.
- Interface de chat básica.
- Integração HTTP com um endpoint de backend configurável.
- Configuração separada em `AiConfig.kt`.

## Importante: conectar a IA
Por segurança, o aplicativo **não contém uma chave secreta de provedor de IA**. APKs podem ser descompilados, então chaves secretas devem ficar no servidor.

1. Abra o projeto no Android Studio.
2. Em `app/src/main/java/com/example/aiinternet/AiConfig.kt`, substitua `https://YOUR_BACKEND_URL/v1/chat` pela URL HTTPS do seu backend.
3. Configure o backend para aceitar `POST` JSON como `{"message":"Olá"}` e devolver JSON como `{"reply":"Olá! Como posso ajudar?"}`.
4. O backend deve chamar o provedor de IA usando a chave guardada no servidor.
5. Sincronize o Gradle e compile em **Build > Build APK(s)**.

## Requisitos
- Android Studio recente.
- JDK 17.
- Android SDK 35 instalado.

## Observações
- O template não inclui VPN.
- A permissão INTERNET é normal e não pede confirmação em tempo de execução.
- O endpoint de exemplo é um placeholder; a IA não funcionará até configurar um backend real.
- Use apenas um backend e um serviço de IA que você esteja autorizado a acessar.
