package com.example.aiinternet

/**
 * Configure aqui a URL HTTPS do SEU backend, que deve chamar o provedor de IA.
 * Exemplo: https://seu-dominio.com/api/chat
 *
 * Não coloque uma chave secreta de IA dentro do APK: ela pode ser extraída.
 */
object AiConfig {
    const val CHAT_ENDPOINT = "https://YOUR_BACKEND_URL/v1/chat"
}
