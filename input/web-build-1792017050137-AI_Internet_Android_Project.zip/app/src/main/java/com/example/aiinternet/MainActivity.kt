package com.example.aiinternet

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var conversation: TextView
    private lateinit var prompt: EditText
    private lateinit var sendButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.WHITE)
        }

        val heading = TextView(this).apply {
            text = "Assistente IA"
            textSize = 24f
            setTextColor(Color.rgb(25, 35, 55))
        }
        root.addView(heading)

        val subtitle = TextView(this).apply {
            text = "Conecte um backend seguro para habilitar as respostas da IA."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 12)
        }
        root.addView(subtitle)

        val scroll = ScrollView(this)
        conversation = TextView(this).apply {
            text = "Você: Olá!\nIA: Configure o endpoint em AiConfig.kt para começar.\n"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(12, 12, 12, 12)
        }
        scroll.addView(conversation)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        prompt = EditText(this).apply {
            hint = "Digite sua mensagem..."
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP
        }
        root.addView(prompt)

        sendButton = Button(this).apply {
            text = "Enviar para IA"
            setOnClickListener { sendMessage() }
        }
        root.addView(sendButton)
        setContentView(root)
    }

    private fun sendMessage() {
        val message = prompt.text.toString().trim()
        if (message.isEmpty()) return

        if (AiConfig.CHAT_ENDPOINT.contains("YOUR_BACKEND_URL")) {
            appendText("\nVocê: $message\nSistema: Configure AiConfig.CHAT_ENDPOINT.kt com a URL HTTPS do seu backend.\n")
            return
        }

        prompt.setText("")
        sendButton.isEnabled = false
        appendText("\nVocê: $message\nIA: aguardando resposta...\n")

        thread {
            var responseText = ""
            var errorText: String? = null
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(AiConfig.CHAT_ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("message", message).toString()
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (status in 200..299) {
                    val json = JSONObject(raw)
                    responseText = json.optString("reply", raw)
                } else {
                    errorText = "O servidor respondeu HTTP $status."
                }
            } catch (e: Exception) {
                errorText = "Não foi possível conectar. Verifique o endpoint e a internet."
            } finally {
                connection?.disconnect()
            }

            runOnUiThread {
                val answer = errorText ?: responseText
                appendText("IA: $answer\n")
                sendButton.isEnabled = true
            }
        }
    }

    private fun appendText(value: String) {
        conversation.append(value)
    }
}
