package com.example.painelff;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView[] valueLabels = new TextView[5];
    private SeekBar[] bars = new SeekBar[5];
    private final String[] names = {"Geral", "Ponto vermelho", "Mira 2x", "Mira 4x", "AWM"};
    private final int[] values = {92, 88, 82, 76, 48};
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(20,9,9));
        getWindow().setNavigationBarColor(Color.rgb(9,9,13));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(Color.rgb(9,9,13));
        scroll.addView(root);
        setContentView(scroll);
        buildUi();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void addGap(int h) {
        View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15); b.setBackground(bg(color, 16));
        return b;
    }
    private void buildUi() {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(16), dp(16), dp(16), dp(16));
        header.setBackground(bg(Color.rgb(48,14,17), 20));
        TextView logo = text("🔥 FF", 28, Color.WHITE, true);
        header.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView tag = text("PAINEL PRO", 12, Color.rgb(255,120,105), true);
        header.addView(tag); root.addView(header);
        addGap(16);
        TextView subtitle = text("SENSIBILIDADE • TREINO • DESEMPENHO", 12, Color.rgb(255,91,75), true);
        root.addView(subtitle); addGap(10);
        Button launch = button("▶  ABRIR FREE FIRE", Color.rgb(205,42,39));
        launch.setOnClickListener(v -> openFreeFire());
        root.addView(launch, new LinearLayout.LayoutParams(-1, dp(54)));
        addGap(18);
        root.addView(text("GERADOR DE SENSIBILIDADE", 20, Color.WHITE, true));
        addGap(5);
        root.addView(text("Ajusta os valores e guarda como referência para configurar no jogo.", 13, Color.rgb(180,177,185), false));
        addGap(12);
        for (int i=0;i<names.length;i++) addSensitivityRow(i);
        Button generate = button("✦  GERAR SUGESTÃO", Color.rgb(105,34,39));
        generate.setOnClickListener(v -> generateProfile());
        root.addView(generate, new LinearLayout.LayoutParams(-1, dp(50)));
        addGap(10);
        Button save = button("COPIAR PERFIL", Color.rgb(45,43,52));
        save.setOnClickListener(v -> copyProfile());
        root.addView(save, new LinearLayout.LayoutParams(-1, dp(48)));
        addGap(22);
        root.addView(text("FERRAMENTAS DE TREINO", 20, Color.WHITE, true)); addGap(10);
        addToolCard("🎯  Treino de mira", "Faça sessões curtas de acompanhamento e precisão.", "Dica: mantenha a mira na altura da cabeça e pratique movimentos controlados.");
        addToolCard("↗  Controlo de recoil", "Exercício de puxada e estabilidade, sem alterar o jogo.", "Treino: faça séries de 10 disparos no campo de treino e ajuste o movimento aos poucos.");
        addToolCard("📱  Dispositivo", "Veja o modelo do telemóvel nas definições do Android.", "Este painel não lê nem modifica dados internos do Free Fire.");
        addGap(14);
        TextView note = text("Ferramenta independente e não oficial. Não inclui aimbot, wallhack nem alterações automáticas ao jogo.", 12, Color.rgb(153,148,158), false);
        root.addView(note);
    }
    private void addSensitivityRow(int i) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(14), dp(10), dp(14), dp(8));
        card.setBackground(bg(Color.rgb(26,25,31), 14));
        LinearLayout line = new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(names[i], 15, Color.WHITE, true);
        line.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        valueLabels[i] = text(String.valueOf(values[i]), 16, Color.rgb(255,104,90), true);
        line.addView(valueLabels[i]); card.addView(line);
        bars[i] = new SeekBar(this); bars[i].setMax(100); bars[i].setProgress(values[i]);
        bars[i].setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255,65,53)));
        bars[i].setThumbTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255,100,85)));
        final int index=i;
        bars[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { values[index]=p; valueLabels[index].setText(String.valueOf(p)); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        card.addView(bars[i]);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin=dp(8);
        root.addView(card, lp);
    }
    private void generateProfile() {
        Random r = new Random();
        values[0] = 85 + r.nextInt(16);
        values[1] = 80 + r.nextInt(21);
        values[2] = 72 + r.nextInt(24);
        values[3] = 65 + r.nextInt(26);
        values[4] = 35 + r.nextInt(36);
        for(int i=0;i<bars.length;i++){ bars[i].setProgress(values[i]); valueLabels[i].setText(String.valueOf(values[i])); }
        Toast.makeText(this, "Sugestão criada! Testa e ajusta no treino.", Toast.LENGTH_LONG).show();
    }
    private void copyProfile() {
        StringBuilder s = new StringBuilder("Meu perfil de sensibilidade FF\n");
        for(int i=0;i<names.length;i++) s.append(names[i]).append(": ").append(values[i]).append("\n");
        android.content.ClipboardManager cm = (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Perfil FF", s.toString()));
        Toast.makeText(this, "Perfil copiado.", Toast.LENGTH_SHORT).show();
    }
    private void addToolCard(String title, String desc, String tip) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(13),dp(14),dp(13)); card.setBackground(bg(Color.rgb(26,25,31),16));
        TextView t = text(title,16,Color.WHITE,true); card.addView(t);
        TextView d = text(desc,13,Color.rgb(190,185,197),false); d.setPadding(0,dp(5),0,dp(9)); card.addView(d);
        Button b = button("VER DICA", Color.rgb(73,35,43));
        b.setOnClickListener(v -> Toast.makeText(this, tip, Toast.LENGTH_LONG).show()); card.addView(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(10); root.addView(card,lp);
    }
    private void openFreeFire() {
        String packageName = "com.dts.freefireth";
        PackageManager pm = getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(packageName);
        if (intent != null) {
            try { startActivity(intent); }
            catch (Exception e) { Toast.makeText(this, "Não foi possível abrir o Free Fire.", Toast.LENGTH_LONG).show(); }
        } else {
            Toast.makeText(this, "Free Fire normal não encontrado. Instala o jogo oficial e tenta novamente.", Toast.LENGTH_LONG).show();
        }
    }
}
