# FF Key Launcher — projeto Android

Projeto-base Android Studio em Java com:
- Tela de acesso que aceita a key de demonstração `Meneses@`.
- Botão para abrir Free Fire normal ou Free Fire MAX, se instalado.
- Seletor de arquivos do Android (`ACTION_OPEN_DOCUMENT`).
- Simulador local de mira: toque nos alvos desenhados dentro do próprio aplicativo para contar pontos.

## Limitações importantes
- Este é um projeto separado; não é uma modificação do APK `proxy.android.4.0.2.apk` enviado.
- O modo de mira é apenas um minijogo de treino dentro do aplicativo. Não automatiza a mira, não injeta código e não altera arquivos ou memória do Free Fire.
- Selecionar um arquivo apenas concede ao aplicativo acesso de leitura ao arquivo escolhido; não o injeta no jogo.
- A key é fixa no código e pode ser extraída de um APK compilado. Para autenticação real, use validação em servidor.
- O projeto não inclui wrapper Gradle. Abra a pasta no Android Studio recente, deixe sincronizar os plugins e compile por Build > Build APK(s).

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35 (o Android Studio pode instalar o SDK necessário)
