// ===== Mendes — Gerador de Sensibilidade Free Fire =====

const sensNames = [
  "Geral",
  "Ponto Vermelho",
  "Mira 2x",
  "Mira 4x",
  "Mira AWM",
  "Olhar Livre",
  "Botão de Disparo"
];

const tipsByEstilo = {
  rusher:
    "• Semi-abra o foco automático.\n• Priorize MOVIMENTAÇÃO e BOTÃO DE DISPARO altos.\n• Use mira curta e corra sempre na diagonal.",
  sniper:
    "• Mantenha a sensibilidade de mira 2x/4x mais baixa.\n• Ajuste a sensibilidade AWM conforme o dispositivo.\n• Ative a mira com o toque rápido (one tap).",
  equilibrado:
    "• Balance MIRA VERMELHA e OLHAR LIVRE.\n• Pratique drag headshot no campo de treinamento.\n• Ajuste aos poucos de 2 em 2 pontos.",
  movimentado:
    "• OLHAR LIVRE e MIRA 2x bem alto para drag headshot.\n• Desative o foco automático.\n• Pratique o arraste rápido na mira curta."
};

function getRandomSens(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRanges(estilo) {
  if (estilo === "rusher") {
    return [90, 100, 85, 100, 80, 100, 95, 100, 85, 100, 90, 100, 90, 100];
  }
  if (estilo === "sniper") {
    return [70, 85, 55, 75, 40, 60, 35, 55, 30, 50, 65, 85, 75, 95];
  }
  if (estilo === "movimentado") {
    return [80, 95, 70, 90, 65, 85, 55, 75, 40, 65, 85, 100, 85, 100];
  }
  // equilibrado
  return [80, 95, 70, 90, 55, 80, 50, 75, 45, 70, 75, 95, 80, 100];
}

function gerarSensibilidade() {
  const nome = document.getElementById("nome").value.trim() || "Jogador";
  const dispositivo = document.getElementById("dispositivo").value;
  const estilo = document.getElementById("estilo").value;
  const dedos = document.getElementById("dedos").value;
  const arma = document.getElementById("arma").value.trim() || "Qualquer arma";

  const ranges = getRanges(estilo);

  // Ajuste por dispositivo
  let minAdj = 0;
  if (dispositivo === "tablet") minAdj = -8;
  if (dispositivo === "emulador") minAdj = -15;

  // Ajuste por nº de dedos (mais dedos = mais sensibilidade)
  const dedosAdj = (parseInt(dedos) - 2) * 4;

  const valores = sensNames.map((_, i) => {
    const min = Math.max(20, ranges[i * 2] + minAdj + dedosAdj);
    const max = Math.min(100, ranges[i * 2 + 1] + minAdj + dedosAdj);
    return getRandomSens(min, max);
  });

  // Monta grid
  const grid = document.getElementById("sensGrid");
  grid.innerHTML = "";
  sensNames.forEach((s, i) => {
    const div = document.createElement("div");
    div.className = "sens-item";
    div.innerHTML = `<div class="nome">${s}</div><div class="valor">${valores[i]}</div>`;
    grid.appendChild(div);
  });

  // Título e dicas
  document.getElementById("tituloResultado").textContent = `🔥 Sensibilidade de ${nome}`;
  document.getElementById("tips").textContent =
    tipsByEstilo[estilo] +
    `\n\n📱 Dispositivo: ${dispositivo}\n🖐️ Dedos: ${dedos}\n🔫 Arma principal: ${arma}\n🎯 Estilo: ${estilo}`;

  document.getElementById("resultado").classList.remove("hidden");

  // Guarda texto p/ copiar
  let texto = `MENDES — Sensibilidade Free Fire\nJogador: ${nome}\nDispositivo: ${dispositivo} | Dedos: ${dedos} | Estilo: ${estilo}\nArma: ${arma}\n`;
  sensNames.forEach((s, i) => (texto += `\n${s}: ${valores[i]}`));
  window.__sensTexto = texto;
}

document.getElementById("gerarBtn").addEventListener("click", gerarSensibilidade);
document.getElementById("novaBtn").addEventListener("click", gerarSensibilidade);

document.getElementById("copiarBtn").addEventListener("click", () => {
  navigator.clipboard.writeText(window.__sensTexto || "").then(() => {
    const btn = document.getElementById("copiarBtn");
    btn.textContent = "✅ Copiado!";
    setTimeout(() => (btn.textContent = "📋 Copiar Configuração"), 1500);
  });
});
