package com.klh4x.demo;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int pink = Color.rgb(245, 0, 170);
    private final int bg = Color.rgb(10, 10, 17);
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24));
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView brand = text("● PROXY KLH4X 11.0", 19, Color.WHITE, true);
        root.addView(brand);
        TextView online = text("● Online", 13, Color.rgb(0, 220, 120), false);
        online.setPadding(0, dp(4), 0, dp(20));
        root.addView(online);

        TextView heading = text("Seus módulos", 29, Color.WHITE, true);
        root.addView(heading);
        TextView subtitle = text("Escolha como você quer jogar.", 14, 0xFFB8B8C8, false);
        subtitle.setPadding(0, 0, 0, dp(18));
        root.addView(subtitle);

        TextView connected = text("●  Dispositivo conectado", 14, 0xFF25D58A, false);
        connected.setPadding(dp(14), dp(13), dp(14), dp(13));
        connected.setBackground(panel());
        root.addView(connected, params());

        addModule("Aimbot + Esp", "Configure seu módulo.", true);
        TextView selected = text("MÓDULO SELECIONADO", 11, pink, true);
        selected.setPadding(dp(8), dp(16), 0, dp(4));
        root.addView(selected);
        addModule("Bypaas", "Selecione para ativar.", false);

        Button inject = new Button(this);
        inject.setText("Injetar");
        inject.setAllCaps(false);
        inject.setTextSize(17);
        inject.setTextColor(Color.WHITE);
        inject.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        inject.setBackground(round(pink, 18));
        LinearLayout.LayoutParams ip = params();
        ip.topMargin = dp(12);
        ip.bottomMargin = dp(16);
        root.addView(inject, ip);
        inject.setOnClickListener(v -> Toast.makeText(this,
            "Demonstração visual: não injeta nem modifica o jogo.", Toast.LENGTH_LONG).show());

        TextView creator = text("Criador klh4x ff apelido KLH4X", 12, pink, true);
        creator.setPadding(dp(4), dp(3), 0, dp(20));
        root.addView(creator);

        Button open = new Button(this);
        open.setText("Abrir Free Fire");
        open.setAllCaps(false);
        open.setTextColor(Color.WHITE);
        open.setTextSize(16);
        open.setBackground(round(0xFF252533, 14));
        root.addView(open, params());
        open.setOnClickListener(v -> launchGame());

        TextView footer = text("Módulos     •     Conexão", 13, 0xFFB8B8C8, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(24), 0, 0);
        root.addView(footer);
        setContentView(scroll);
    }

    private void addModule(String title, String desc, boolean checked) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setPadding(dp(12), dp(12), dp(8), dp(12));
        card.setBackground(panel());
        LinearLayout.LayoutParams cp = params();
        cp.topMargin = dp(10);
        root.addView(card, cp);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView name = text(title, 17, Color.WHITE, true);
        TextView detail = text(desc, 13, 0xFFB8B8C8, false);
        detail.setPadding(0, dp(5), 0, 0);
        labels.addView(name);
        labels.addView(detail);
        card.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));

        Switch toggle = new Switch(this);
        toggle.setButtonTintList(null);
        toggle.setChecked(checked);
        toggle.setText("");
        card.addView(toggle);
    }

    private void launchGame() {
        String[] packages = {"com.dts.freefireth", "com.dts.freefiremax"};
        for (String p : packages) {
            Intent i = getPackageManager().getLaunchIntentForPackage(p);
            if (i != null) { startActivity(i); return; }
        }
        Toast.makeText(this, "Free Fire não encontrado. Verifique se está instalado.", Toast.LENGTH_LONG).show();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable panel() { return round(0xFF171721, 15); }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }
}
