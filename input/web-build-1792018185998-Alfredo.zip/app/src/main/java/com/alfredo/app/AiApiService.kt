package com.alfredo.app

import retrofit2.http.Body
import retrofit2.http.POST

data class AiRequest(val prompt: String)
data class AiResponse(val text: String)

interface AiApiService {
    @POST("v1/chat/completions")
    suspend fun getChatCompletion(@Body request: AiRequest): AiResponse
}
