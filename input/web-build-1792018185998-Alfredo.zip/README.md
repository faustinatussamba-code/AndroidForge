# Alfredo Android Project

This project is a template for an Android application in Kotlin with AI API integration.
