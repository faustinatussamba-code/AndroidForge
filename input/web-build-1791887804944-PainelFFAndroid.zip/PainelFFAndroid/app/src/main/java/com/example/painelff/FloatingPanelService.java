package com.example.painelff;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingPanelService extends Service {
    private WindowManager windowManager;
    private View panel;
    private WindowManager.LayoutParams params;
    private int startX, startY;
    private float touchX, touchY;
    private boolean expanded = true;
    private LinearLayout content;

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.rgb(245, 75, 63)); return d;
    }
    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private Button button(String value) {
        Button b = new Button(this); b.setText(value); b.setTextColor(Color.WHITE); b.setTextSize(12);
        b.setAllCaps(false); b.setPadding(dp(6), 0, dp(6), 0); b.setBackground(background(Color.rgb(125, 31, 36), 10));
        return b;
    }

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Autorize sobreposição nas definições do Painel FF.", Toast.LENGTH_LONG).show();
            stopSelf(); return;
        }
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        createPanel();
        try { windowManager.addView(panel, params); }
        catch (Exception e) { Toast.makeText(this, "Não foi possível mostrar o painel flutuante.", Toast.LENGTH_LONG).show(); stopSelf(); }
    }

    private void createPanel() {
        LinearLayout outer = new LinearLayout(this); outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(10), dp(7), dp(10), dp(9)); outer.setBackground(background(Color.rgb(20, 10, 14), 15));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("🔥 FF PANEL", 14, Color.WHITE, true);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(38), 1));
        Button fold = button(expanded ? "−" : "+");
        header.addView(fold, new LinearLayout.LayoutParams(dp(42), dp(36)));
        Button close = button("×");
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(38), dp(36)); cp.leftMargin=dp(5); header.addView(close, cp);
        outer.addView(header);

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        TextView info = label("Sensibilidade sugerida\nGeral 92  •  Red Dot 88\nMira 2x 82  •  4x 76  •  AWM 48", 12, Color.rgb(230, 222, 226), false);
        info.setPadding(dp(4), dp(7), dp(4), dp(8)); content.addView(info);
        Button open = button("▶  ABRIR FREE FIRE");
        content.addView(open, new LinearLayout.LayoutParams(-1, dp(40)));
        TextView note = label("Painel de referência • sem cheats", 10, Color.rgb(175, 160, 168), false);
        note.setGravity(Gravity.CENTER); note.setPadding(0, dp(5), 0, 0); content.addView(note);
        outer.addView(content);
        fold.setOnClickListener(v -> {
            expanded = !expanded; content.setVisibility(expanded ? View.VISIBLE : View.GONE);
            fold.setText(expanded ? "−" : "+");
            params.width = dp(expanded ? 245 : 180);
            try { windowManager.updateViewLayout(panel, params); } catch (Exception ignored) {}
        });
        close.setOnClickListener(v -> stopSelf());
        open.setOnClickListener(v -> openFreeFire());
        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = params.x; startY = params.y; touchX = event.getRawX(); touchY = event.getRawY(); return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = startX + (int)(event.getRawX() - touchX);
                    params.y = startY + (int)(event.getRawY() - touchY);
                    try { windowManager.updateViewLayout(panel, params); } catch (Exception ignored) {} return true;
                default: return false;
            }
        });
        panel = outer;
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(245), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END; params.x = dp(12); params.y = dp(100);
    }

    private void openFreeFire() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if (launch == null) { Toast.makeText(this, "Free Fire normal não encontrado no aparelho.", Toast.LENGTH_LONG).show(); return; }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(launch); } catch (Exception e) { Toast.makeText(this, "Não foi possível abrir o jogo.", Toast.LENGTH_LONG).show(); }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }
    @Override public void onDestroy() {
        if (windowManager != null && panel != null) { try { windowManager.removeView(panel); } catch (Exception ignored) {} }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
