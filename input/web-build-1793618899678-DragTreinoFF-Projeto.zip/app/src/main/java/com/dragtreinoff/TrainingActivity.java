package com.dragtreinoff;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

public class TrainingActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(17,17,22));
        DragPad pad = new DragPad();
        frame.addView(pad, new FrameLayout.LayoutParams(-1,-1));
        TextView help = new TextView(this);
        help.setText("DRAG TREINO  •  Arraste o dedo do círculo até o alvo\nToque em qualquer lugar para reposicionar e tentar novamente.");
        help.setTextColor(Color.WHITE);
        help.setTextSize(15);
        help.setPadding(24,24,24,24);
        help.setBackgroundColor(Color.rgb(35,25,35));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, FrameLayout.LayoutParams.WRAP_CONTENT);
        hp.gravity = android.view.Gravity.TOP;
        frame.addView(help, hp);
        setContentView(frame);
    }

    private class DragPad extends View {
        Paint p = new Paint(3);
        float sx, sy, tx, ty;
        boolean initialized = false;
        String status = "Arraste do círculo rosa até o alvo";
        int score = 0;

        DragPad() { super(TrainingActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

        void setup() {
            sx = getWidth() * 0.25f;
            sy = getHeight() * 0.62f;
            tx = getWidth() * 0.75f;
            ty = getHeight() * 0.42f;
            initialized = true;
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            if (!initialized && getWidth() > 0 && getHeight() > 0) setup();
            c.drawColor(Color.rgb(17,17,22));
            p.setColor(Color.rgb(55,45,60)); p.setStrokeWidth(3); p.setStyle(Paint.Style.STROKE);
            c.drawLine(sx, sy, tx, ty, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(255,65,155)); c.drawCircle(sx, sy, 34, p);
            p.setColor(Color.WHITE); c.drawCircle(sx, sy, 9, p);
            p.setColor(Color.rgb(160,32,240)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5);
            c.drawCircle(tx, ty, 45, p); c.drawCircle(tx, ty, 22, p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextSize(22);
            c.drawText("Acertos: " + score, 28, getHeight()-85, p);
            p.setTextSize(17); c.drawText(status, 28, getHeight()-48, p);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                float dx = e.getX()-sx, dy = e.getY()-sy;
                if (dx*dx + dy*dy < 75*75) {
                    status = "Continue arrastando até o alvo";
                    invalidate();
                } else {
                    sx = e.getX(); sy = e.getY();
                    tx = getWidth()*0.75f; ty = getHeight()*0.42f;
                    status = "Novo ponto inicial";
                    invalidate();
                }
                return true;
            } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                sx = e.getX(); sy = e.getY();
                float dx = sx-tx, dy = sy-ty;
                if (dx*dx + dy*dy < 48*48) { status = "Boa! Alvo alcançado"; }
                invalidate();
                return true;
            } else if (e.getAction() == MotionEvent.ACTION_UP) {
                float dx = e.getX()-tx, dy = e.getY()-ty;
                if (dx*dx + dy*dy < 65*65) { score++; status = "Acertou! Tente novamente"; }
                else { status = "Tente chegar mais perto do alvo"; }
                sx = getWidth()*0.25f; sy = getHeight()*0.62f;
                invalidate();
                return true;
            }
            return true;
        }
    }
}
