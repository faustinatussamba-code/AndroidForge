package com.dragtreinoff;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(225, 40, 130)));
        return b;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private LinearLayout root() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(24), dp(24), dp(24), dp(24));
        l.setBackgroundColor(Color.rgb(17, 17, 22));
        return l;
    }

    private void showHome() {
        LinearLayout l = root();
        TextView title = text("DRAG TREINO FF", 27);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(255, 70, 160));
        l.addView(title, new LinearLayout.LayoutParams(-1, dp(70)));
        TextView info = text("Treine o movimento de arrasto.\nEste app não controla a mira nem altera o Free Fire.", 16);
        l.addView(info, new LinearLayout.LayoutParams(-1, dp(100)));
        Button train = button("Começar treino de drag");
        l.addView(train, new LinearLayout.LayoutParams(-1, dp(58)));
        train.setOnClickListener(v -> startActivity(new Intent(this, TrainingActivity.class)));

        Button floating = button("Ativar botão flutuante DRAG");
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(58));
        fp.topMargin = dp(14);
        l.addView(floating, fp);
        floating.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                startService(new Intent(this, FloatingDragService.class));
                floating.setText("Botão flutuante ativado");
            } else {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });
        TextView note = text("O botão flutuante abre a área de treino. Para desligá-lo, volte ao app e toque em Parar botão flutuante.", 13);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, dp(80));
        np.topMargin = dp(12);
        l.addView(note, np);
        Button stop = button("Parar botão flutuante");
        l.addView(stop, new LinearLayout.LayoutParams(-1, dp(54)));
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingDragService.class));
            showHome();
        });
        setContentView(l);
    }
}
