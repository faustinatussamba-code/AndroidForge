DRAG TREINO FF — projeto Android Java

O que inclui:
- Tela de treino para praticar arrasto com um alvo visual.
- Botão flutuante DRAG que pode ser movido pela tela e abre a área de treino.
- Não injeta arquivos, não altera o Free Fire e não automatiza toques no jogo.

Como compilar:
1. Extraia o ZIP.
2. Abra a pasta DragTreinoFF no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use Build > Build APK(s).
5. O APK de debug normalmente fica em app/build/outputs/apk/debug/app-debug.apk.

O projeto usa Android Gradle Plugin 8.6.1 e compileSdk 35.
A permissão de sobreposição só é solicitada quando você ativa o botão flutuante.
