# FF Key Launcher (projeto Android)

Projeto-base Android Studio em Java com:
- Tela de acesso que aceita a key `Meneses@`.
- Botão para abrir Free Fire normal ou Free Fire MAX se estiver instalado.
- Seletor de arquivos do Android (ACTION_OPEN_DOCUMENT).

## Limitações importantes
- Este é um projeto separado; não é uma modificação do APK `proxy.android.4.0.2.apk` enviado.
- Selecionar um arquivo não injeta o arquivo no Free Fire e não modifica os dados do jogo.
- A key é fixa no código e pode ser extraída de um APK compilado. Para controle de acesso real, use autenticação num servidor.
- Não inclui wrapper Gradle. Abra a pasta no Android Studio recente, deixe sincronizar os plugins e compile pelo menu Build > Build APK(s).

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35 (o Android Studio pode instalar o SDK necessário)
