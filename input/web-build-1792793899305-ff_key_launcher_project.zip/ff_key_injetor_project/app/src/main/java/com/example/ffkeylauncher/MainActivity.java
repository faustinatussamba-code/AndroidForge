package com.example.ffkeylauncher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import java.util.Random;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    // Demo-only gate: a key embedded in an APK can be extracted by reverse engineering.
    private static final String ACCESS_KEY = "Meneses@";
    private static final int PICK_FILE_REQUEST = 101;
    private EditText keyInput;
    private TextView status;
    private Uri selectedFile;
    private boolean unlocked = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 24, 39));
        getWindow().setNavigationBarColor(Color.rgb(16, 24, 39));
        showLogin();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout baseLayout() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(16, 24, 39));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);
        return root;
    }

    private void addSpace(LinearLayout root, int height) {
        View v = new View(this);
        root.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void showLogin() {
        LinearLayout root = baseLayout();
        addSpace(root, 48);
        TextView title = text("FF KEY LAUNCHER", 26, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        addSpace(root, 8);
        root.addView(text("Acesso por chave • Free Fire • Arquivos", 14, Color.LTGRAY));
        addSpace(root, 36);
        keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setHint("Digite a key");
        keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(Color.GRAY);
        keyInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        keyInput.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(96, 165, 250)));
        root.addView(keyInput, new LinearLayout.LayoutParams(-1, dp(54)));
        addSpace(root, 16);
        Button enter = button("Entrar");
        root.addView(enter, new LinearLayout.LayoutParams(-1, dp(52)));
        enter.setOnClickListener(v -> {
            if (ACCESS_KEY.equals(keyInput.getText().toString())) {
                unlocked = true;
                showHome();
            } else {
                Toast.makeText(this, "Key inválida", Toast.LENGTH_SHORT).show();
            }
        });
        addSpace(root, 24);
        TextView note = text("Aviso: esta key fica dentro do APK e pode ser descoberta. Este app seleciona arquivos e abre o jogo; não injeta nem altera arquivos internos do Free Fire.", 13, Color.LTGRAY);
        root.addView(note);
    }

    private void showHome() {
        LinearLayout root = baseLayout();
        addSpace(root, 24);
        TextView title = text("Painel FF", 26, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        addSpace(root, 8);
        root.addView(text("Acesso autorizado", 15, Color.rgb(134, 239, 172)));
        addSpace(root, 28);

        Button choose = button("Selecionar arquivo");
        root.addView(choose, new LinearLayout.LayoutParams(-1, dp(52)));
        choose.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            startActivityForResult(intent, PICK_FILE_REQUEST);
        });

        addSpace(root, 12);
        status = text(selectedFile == null ? "Nenhum arquivo selecionado" : "Arquivo: " + displayName(selectedFile), 14, Color.LTGRAY);
        root.addView(status);
        addSpace(root, 24);

        Button launch = button("Abrir Free Fire");
        root.addView(launch, new LinearLayout.LayoutParams(-1, dp(52)));
        launch.setOnClickListener(v -> launchFreeFire());
        addSpace(root, 12);

        Button aimTest = button("Aimbot de teste (simulador)");
        root.addView(aimTest, new LinearLayout.LayoutParams(-1, dp(52)));
        aimTest.setOnClickListener(v -> showAimTest());
        addSpace(root, 12);

        Button changeKey = button("Voltar à tela de acesso");
        root.addView(changeKey, new LinearLayout.LayoutParams(-1, dp(48)));
        changeKey.setOnClickListener(v -> { unlocked = false; showLogin(); });
        addSpace(root, 28);
        root.addView(text("A seleção do arquivo apenas concede acesso de leitura ao arquivo escolhido. Ela não injeta arquivos no jogo nem modifica dados protegidos.", 13, Color.LTGRAY));
    }


    private void showAimTest() {
        LinearLayout root = baseLayout();
        addSpace(root, 12);
        TextView title = text("SIMULADOR DE MIRA", 24, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        addSpace(root, 8);
        root.addView(text("Treino isolado: toque no alvo para marcar pontos. Não controla nem injeta nada no Free Fire.", 14, Color.LTGRAY));
        addSpace(root, 16);
        TextView score = text("Pontos: 0", 18, Color.rgb(134, 239, 172));
        root.addView(score);
        addSpace(root, 12);
        Button liteAim = button("Aimbot Lite: DESLIGADO (simulado)");
        root.addView(liteAim, new LinearLayout.LayoutParams(-1, dp(50)));
        addSpace(root, 10);
        AimPracticeView practice = new AimPracticeView();
        LinearLayout.LayoutParams gameArea = new LinearLayout.LayoutParams(-1, dp(390));
        root.addView(practice, gameArea);
        practice.setOnScoreChanged(points -> score.setText("Pontos: " + points));
        liteAim.setOnClickListener(v -> {
            boolean enabled = practice.toggleLiteAim();
            liteAim.setText(enabled ? "Aimbot Lite: LIGADO (simulado)" : "Aimbot Lite: DESLIGADO (simulado)");
        });
        addSpace(root, 16);
        Button back = button("Voltar ao painel");
        root.addView(back, new LinearLayout.LayoutParams(-1, dp(50)));
        back.setOnClickListener(v -> showHome());
    }

    private interface ScoreListener { void onScoreChanged(int score); }

    private class AimPracticeView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random random = new Random();
        private float targetX = 160, targetY = 180;
        private float targetRadius = dp(25);
        private int points = 0;
        private boolean liteAimEnabled = false;
        private ScoreListener listener;

        AimPracticeView() { super(MainActivity.this); setBackgroundColor(Color.rgb(9, 15, 28)); }
        void setOnScoreChanged(ScoreListener callback) { listener = callback; }
        boolean toggleLiteAim() {
            liteAimEnabled = !liteAimEnabled;
            invalidate();
            return liteAimEnabled;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (targetX > getWidth() || targetY > getHeight()) moveTarget();
            paint.setColor(Color.rgb(96, 165, 250));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(3));
            canvas.drawCircle(targetX, targetY, targetRadius + dp(8), paint);
            paint.setColor(Color.rgb(248, 113, 113));
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(targetX, targetY, targetRadius, paint);
            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            canvas.drawCircle(targetX, targetY, targetRadius / 2, paint);
            canvas.drawLine(targetX - targetRadius - dp(12), targetY, targetX + targetRadius + dp(12), targetY, paint);
            canvas.drawLine(targetX, targetY - targetRadius - dp(12), targetX, targetY + targetRadius + dp(12), paint);
            // Lite aim is deliberately confined to this training canvas. It never
            // reads or controls Free Fire, other apps, or device touch input.
            float crossX = liteAimEnabled ? targetX : getWidth() / 2f;
            float crossY = liteAimEnabled ? targetY : getHeight() / 2f;
            paint.setColor(liteAimEnabled ? Color.rgb(134, 239, 172) : Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            float arm = dp(12);
            canvas.drawLine(crossX - arm, crossY, crossX - dp(4), crossY, paint);
            canvas.drawLine(crossX + dp(4), crossY, crossX + arm, crossY, paint);
            canvas.drawLine(crossX, crossY - arm, crossX, crossY - dp(4), paint);
            canvas.drawLine(crossX, crossY + dp(4), crossX, crossY + arm, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.LTGRAY);
            paint.setTextSize(dp(12));
            canvas.drawText(liteAimEnabled ? "AIM LITE SIMULADO" : "TOQUE NO ALVO", dp(12), getHeight() - dp(16), paint);
        }

        private void moveTarget() {
            float margin = targetRadius + dp(15);
            targetX = margin + random.nextFloat() * Math.max(1, getWidth() - margin * 2);
            targetY = margin + random.nextFloat() * Math.max(1, getHeight() - margin * 2);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                float dx = event.getX() - targetX;
                float dy = event.getY() - targetY;
                if (dx * dx + dy * dy <= targetRadius * targetRadius) {
                    points++;
                    if (listener != null) listener.onScoreChanged(points);
                    moveTarget();
                    invalidate();
                }
                return true;
            }
            return true;
        }
    }

    private String displayName(Uri uri) {
        String path = uri.getLastPathSegment();
        if (path == null) return uri.toString();
        int colon = path.lastIndexOf(':');
        return colon >= 0 ? path.substring(colon + 1) : path;
    }

    private void launchFreeFire() {
        String[] packages = {"com.dts.freefireth", "com.dts.freefiremax"};
        for (String packageName : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch != null) {
                startActivity(launch);
                return;
            }
        }
        Toast.makeText(this, "Free Fire não encontrado. Instale o jogo oficial e tente novamente.", Toast.LENGTH_LONG).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedFile = data.getData();
            try { getContentResolver().takePersistableUriPermission(selectedFile, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) { }
            if (unlocked) showHome();
        }
    }
}
