# FF Key Launcher

Android Studio starter project (Java) with:
- Demo access key: `Meneses@` (embedded in the APK; not secure against reverse engineering)
- Button to launch the official Free Fire / Free Fire MAX app if installed
- Android document picker to select a file
- Isolated aim-practice canvas with an optional **Aimbot Lite (simulated)** crosshair that tracks the practice target only

## Important limits
The practice mode runs only inside this app. It does not inject code, read game memory, overlay or control Free Fire, automate touches in other apps, or modify game files. File selection grants access to the selected document only; it does not inject it into the game.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build APK(s)**.

### Painel Glassmorphism roxo
Foi incluído `app/src/main/assets/panel.css` com o CSS fornecido e `panel-preview.html` para visualizar o estilo no navegador. Essa é uma prévia visual: o CSS não é aplicado automaticamente à interface nativa Android e o botão de demonstração não injeta código nem modifica o Free Fire. Para ver a prévia, abra `panel-preview.html` em um navegador.
