# Painel feito por Manaces — projeto inicial Android

Este é um projeto-fonte Android (Java) com interface escura e detalhes neon, navegação inferior e telas demonstrativas.

## Abrir
1. Extraia o ZIP.
2. Abra a pasta `PainelFeitoPorManaces` no Android Studio.
3. Aguarde o Gradle sincronizar.
4. Use **Build > Build APK(s)** para gerar um APK de depuração.

## Observações honestas
- O ZIP é o projeto-fonte; não é um APK compilado.
- As telas de sensibilidade, DPI, skins e consulta de ID são demonstrações iniciais.
- A configuração DPI salva o valor apenas na tela; não altera o DPI do sistema.
- O painel flutuante nesta versão abre a página de autorização, mas a janela sobreposta ainda não está implementada.
- A consulta de ID não inventa dados: precisa de uma API/fonte oficial legítima antes de funcionar.
- O recurso visual “Proxy Aimbot” não contém trapaças nem interage com o jogo.
- A logo/arte final e imagens oficiais de personagens ainda precisam ser adicionadas.
