package com.manaces.painel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    int red = Color.rgb(255, 35, 55), bg = Color.rgb(5, 7, 9), card = Color.rgb(12, 17, 21);
    LinearLayout root, content, nav;
    String current = "Início";
    int themeIndex = 0;
    final int[] themes = {Color.rgb(0,145,255), Color.rgb(0,220,70), Color.rgb(255,35,55), Color.rgb(130,130,130), Color.rgb(255,205,0)};
    @Override public void onCreate(Bundle b) { super.onCreate(b); showPage("Início"); }

    GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(14, 8, 14, 8); return t;
    }
    LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void addCard(LinearLayout parent, View child) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(12, 7, 12, 7);
        child.setBackground(shape(card, red, 18)); parent.addView(child, p);
    }
    Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackground(shape(Color.rgb(24,7,10), red, 18)); b.setOnClickListener(v -> action.run()); return b;
    }
    void showPage(String page) {
        current = page;
        root = column(); root.setBackgroundColor(bg);
        TextView header = text("🔥  PAINEL FEITO POR MANACES", 20, red, true);
        header.setGravity(Gravity.CENTER); header.setPadding(10,20,10,18); root.addView(header);
        ScrollView scroll = new ScrollView(this); content = column(); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        buildPage(page);
        nav = row(); nav.setBackgroundColor(Color.rgb(9,13,16));
        String[] pages = {"Início","Sensibilidade","Skins","ID","Mais"};
        for(String p:pages) {
            TextView n = text(p, 11, p.equals(page)?red:Color.LTGRAY, p.equals(page)); n.setGravity(Gravity.CENTER);
            nav.addView(n, new LinearLayout.LayoutParams(0,58,1));
            n.setOnClickListener(v -> showPage(p.equals("Mais") ? "Mais" : p.equals("ID") ? "Consultar ID" : p));
        }
        root.addView(nav); setContentView(root);
    }
    void buildPage(String page) {
        if(page.equals("Início")) {
            TextView welcome = text("Bem-vindo, guerreiro!\\nEscolha uma opção abaixo e personalize sua experiência.",16,Color.WHITE,true); addCard(content,welcome);
            addCard(content, button("🎮  ABRIR FREE FIRE", this::openGame));
            addCard(content, button("🎯  Gerador de Sensibilidade", () -> showPage("Sensibilidade")));
            addCard(content, button("📱  Configurações DPI", () -> showPage("Configurações DPI")));
            addCard(content, button("🪟  Painel Flutuante", () -> showPage("Painel Flutuante")));
            addCard(content, button("🎯  Proxy Aimbot (apenas visual)", () -> showPage("Proxy Aimbot")));
            addCard(content, button("👕  Skins", () -> showPage("Skins")));
            addCard(content, button("🔎  Consultar ID", () -> showPage("Consultar ID")));
        } else if(page.equals("Sensibilidade")) {
            addCard(content,text("GERADOR DE SENSIBILIDADE\\nAjuste os valores e toque em gerar sugestão.",16,Color.WHITE,true));
            String[] labels={"Geral","Ponto Vermelho","Mira 2x","Mira 4x","Mira AWM"};
            for(int i=0;i<labels.length;i++){
                LinearLayout c=column(); c.addView(text(labels[i],15,Color.WHITE,true));
                SeekBar s=new SeekBar(this); s.setMax(200); s.setProgress(new int[]{94,88,76,65,50}[i]); s.setProgressTintList(android.content.res.ColorStateList.valueOf(red)); c.addView(s);
                addCard(content,c);
            }
            addCard(content,button("⚡  GERAR SUGESTÃO",()->new AlertDialog.Builder(this).setTitle("Sugestão gerada").setMessage("Valores sugeridos para você testar. Os resultados variam conforme o aparelho e sua preferência.").setPositiveButton("OK",null).show()));
        } else if(page.equals("Configurações DPI")) {
            addCard(content,text("DPI MANUAL",16,Color.WHITE,true));
            EditText dpi=new EditText(this); dpi.setSingleLine(true); dpi.setHint("Digite o valor de DPI (ex.: 480)"); dpi.setInputType(2); dpi.setTextColor(Color.WHITE); addCard(content,dpi);
            addCard(content,button("Salvar valor",()->{String val=dpi.getText().toString(); if(val.isEmpty()) val="480"; new AlertDialog.Builder(this).setMessage("Valor salvo nesta tela: "+val+". O aplicativo não altera o DPI do sistema automaticamente.").setPositiveButton("OK",null).show();}));
            addCard(content,text("Para mudar o DPI real, use as opções oficiais do Android quando disponíveis.",14,Color.LTGRAY,false));
        } else if(page.equals("Painel Flutuante")) {
            addCard(content,text("PAINEL FLUTUANTE",17,Color.WHITE,true));
            addCard(content,button("Conceder permissão de sobreposição",()->{if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i);}else new AlertDialog.Builder(this).setMessage("Permissão já concedida. A demonstração flutuante ainda precisa ser ativada numa próxima versão.").setPositiveButton("OK",null).show();}));
            addCard(content,text("A tela permite abrir as configurações de permissão. A janela flutuante funcional será adicionada numa próxima etapa.",14,Color.LTGRAY,false));
        } else if(page.equals("Proxy Aimbot")) {
            addCard(content,text("🔥 PROXY AIMBOT\\nAPENAS VISUAL — SEM TRAPAÇAS FUNCIONAIS",18,red,true));
            String[] opts={"HUD personalizado (visual)","Mira de demonstração","Animações de interface","Efeitos de destaque"};
            for(String s:opts){CheckBox cb=new CheckBox(this); cb.setText(s); cb.setTextColor(Color.WHITE); cb.setButtonTintList(android.content.res.ColorStateList.valueOf(red)); addCard(content,cb);}
            addCard(content,text("Esta seção é apenas demonstrativa e não modifica o jogo.",14,Color.LTGRAY,false));
        } else if(page.equals("Skins")) {
            addCard(content,text("SKINS DO FREE FIRE",18,Color.WHITE,true));
            String[] skins={"Alok","Kelly","Hayato","Chrono","Rafael","Moco","Caroline","Antonio","Luna"};
            for(String s:skins) addCard(content,button("👕  "+s,()->new AlertDialog.Builder(this).setMessage("Personagem selecionado: "+s+". Galeria ilustrada será adicionada numa próxima versão.").setPositiveButton("OK",null).show()));
        } else if(page.equals("Consultar ID")) {
            addCard(content,text("CONSULTAR ID",18,Color.WHITE,true));
            EditText id=new EditText(this); id.setSingleLine(true); id.setHint("Digite o ID do jogador"); id.setTextColor(Color.WHITE); addCard(content,id);
            addCard(content,button("Pesquisar",()->new AlertDialog.Builder(this).setTitle("Consulta de ID").setMessage("Ainda não há uma fonte oficial conectada. Nenhuma informação foi consultada.").setPositiveButton("OK",null).show()));
        } else {
            addCard(content,text("PERSONALIZAÇÃO",18,Color.WHITE,true));
            String[] names={"Azul","Verde","Vermelho","Preto","Amarelo"};
            for(int i=0;i<names.length;i++){ final int ix=i; addCard(content,button("●  "+names[i],()->{red=themes[ix]; showPage("Mais");}));}
            addCard(content,button("📱  Configurações do Android",()->startActivity(new Intent(Settings.ACTION_SETTINGS))));
            addCard(content,button("ℹ️  Sobre o painel",()->new AlertDialog.Builder(this).setMessage("Painel feito por Manaces — versão inicial 1.0").setPositiveButton("OK",null).show()));
        }
    }
    void openGame() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if(launch==null) launch=getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
        if(launch!=null) startActivity(launch);
        else new AlertDialog.Builder(this).setMessage("Free Fire não foi encontrado. Instale o jogo pela loja oficial e tente novamente.").setPositiveButton("OK",null).show();
    }
}
