package com.example.ffoptimizer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root;
    private int white = Color.WHITE, muted = Color.rgb(195,205,220);
    private String[] commands = {
        "wm size",
        "wm density",
        "wm size 1080x2400",
        "wm density 420",
        "wm size reset",
        "wm density reset"
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,24);
        root.setBackgroundColor(Color.rgb(16,21,30));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("FF A07 OPTIMIZER");
        title.setTextColor(white); title.setTextSize(24);
        title.setGravity(Gravity.CENTER); title.setPadding(4,12,4,6);
        root.addView(title, params(-1,-2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Free Fire normal • Samsung Galaxy A07");
        subtitle.setTextColor(muted); subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(4,0,4,16); root.addView(subtitle, params(-1,-2));

        addSection("1. Perfil de mira");
        addText("Sugestão inicial para testar no jogo (escala 0–200):");
        addText("Geral: 190  |  Ponto vermelho: 185  |  2x: 175  |  4x: 160  |  AWM: 90  |  Olhadinha: 150");
        addText("Esses valores são sugestões; ajuste conforme seu controle e a escala exibida no jogo.");

        addSection("2. Comandos ADB para Brevent / Shizuku");
        addText("Copie um comando e execute apenas se entender o efeito. O app não executa comandos sozinho.");
        for (String cmd : commands) addCommand(cmd);

        addSection("3. Como usar");
        addText("• Conecte o celular ao ADB/terminal autorizado.");
        addText("• Execute 'wm size' e 'wm density' primeiro para anotar os valores atuais.");
        addText("• Os valores 1080x2400 e 420 são apenas exemplos; podem deixar a interface pequena ou distorcida.");
        addText("• Para restaurar a resolução: wm size reset");
        addText("• Para restaurar a densidade: wm density reset");
        addText("• Não há garantia de 120 Hz: use apenas a taxa suportada pelo aparelho.");

        addSection("4. Limites");
        addText("Este app é um painel de referência/cópia. Não injeta código no Free Fire, não automatiza tiros e não lê memória de outros aplicativos.");

        setContentView(scroll);
    }

    private LinearLayout.LayoutParams params(int w, int h) {
        return new LinearLayout.LayoutParams(w,h);
    }
    private void addSection(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.rgb(105,190,255));
        t.setTextSize(18); t.setPadding(0,18,0,6);
        root.addView(t, params(-1,-2));
    }
    private void addText(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(white); t.setTextSize(14);
        t.setPadding(0,5,0,8); root.addView(t, params(-1,-2));
    }
    private void addCommand(String cmd) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = new TextView(this);
        label.setText(cmd); label.setTextColor(white); label.setTextSize(13);
        row.addView(label, new LinearLayout.LayoutParams(0,-2,1));
        Button copy = new Button(this);
        copy.setText("Copiar");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("ADB command", cmd));
            Toast.makeText(this, "Comando copiado", Toast.LENGTH_SHORT).show();
        });
        row.addView(copy, params(-2,-2));
        root.addView(row, params(-1,-2));
    }
}
