# FF A07 Optimizer (Android Java)

Projeto de referência para Free Fire normal no Samsung Galaxy A07:
- Sugestões de sensibilidade para ajuste manual dentro do jogo.
- Botões para copiar comandos ADB de consulta, exemplo e restauração de tamanho/densidade.
- Instruções de uso e reversão.

O app não executa comandos ADB por conta própria. Os comandos devem ser usados conscientemente em um terminal/ADB autorizado. `wm size 1080x2400` e `wm density 420` são exemplos, não valores universais; anote antes os valores atuais com `wm size` e `wm density`. Restaure com `wm size reset` e `wm density reset`.

## Compilar
1. Extraia o ZIP.
2. Abra a pasta no Android Studio.
3. Aguarde Gradle Sync e instale um Android SDK compatível.
4. Build > Build APK(s).

Este projeto não injeta aimbot/ESP, não altera memória do jogo e não garante aumento de FPS.
