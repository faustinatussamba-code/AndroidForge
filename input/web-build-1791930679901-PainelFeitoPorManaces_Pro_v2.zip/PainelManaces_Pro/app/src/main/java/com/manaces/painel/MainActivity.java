package com.manaces.painel;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    int red=Color.rgb(255,35,55), bg=Color.rgb(4,6,8), card=Color.rgb(11,16,20);
    LinearLayout root, body;
    String active="Início";
    final int[] colors={Color.rgb(0,145,255),Color.rgb(0,220,70),Color.rgb(255,35,55),Color.rgb(125,125,125),Color.rgb(255,205,0)};
    @Override public void onCreate(Bundle b){super.onCreate(b); page("Início");}
    GradientDrawable panel(int fill,int stroke,int radius){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.rgb(Math.min(255,Color.red(fill)+8),Math.min(255,Color.green(fill)+3),Math.min(255,Color.blue(fill)+3)),fill});
        d.setCornerRadius(radius); if(stroke!=0)d.setStroke(2,stroke); return d;
    }
    TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(13,10,13,10);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    void card(View v){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(12,6,12,6);v.setBackground(panel(card,red,20));body.addView(v,p);}
    Button btn(String s,Runnable r){
        Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setAllCaps(false);
        b.setBackground(panel(Color.rgb(22,7,11),red,18));b.setPadding(8,10,8,10);b.setOnClickListener(v->r.run());return b;
    }
    void page(String p){
        active=p;root=vertical();root.setBackgroundColor(bg);
        TextView top=label("🔥  PAINEL FEITO POR MANACES",19,red,true);top.setGravity(Gravity.CENTER);top.setPadding(8,18,8,16);root.addView(top);
        ScrollView sc=new ScrollView(this);body=vertical();sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        build(p);
        LinearLayout nav=new LinearLayout(this);nav.setBackgroundColor(Color.rgb(8,12,15));
        String[] names={"Início","Sensibilidade","Skins","Consultar ID","Mais"};
        String[] icons={"⌂","◎","♟","⌕","•••"};
        for(int i=0;i<names.length;i++){final String dest=names[i];LinearLayout item=vertical();TextView ic=label(icons[i],21,dest.equals(p)?red:Color.LTGRAY,true);ic.setGravity(Gravity.CENTER);TextView tx=label(names[i].equals("Consultar ID")?"ID":names[i],9,dest.equals(p)?red:Color.LTGRAY,false);tx.setGravity(Gravity.CENTER);item.addView(ic);item.addView(tx);nav.addView(item,new LinearLayout.LayoutParams(0,58,1));item.setOnClickListener(v->page(dest));}
        root.addView(nav);setContentView(root);
    }
    void build(String p){
        if(p.equals("Início")){
            TextView hero=label("🔥 FF\\nPAINEL FEITO POR MANACES\\nSEU JOGO, NOSSO FOCO!",23,Color.WHITE,true);hero.setGravity(Gravity.CENTER);hero.setBackground(panel(Color.rgb(25,4,8),red,22));card(hero);
            TextView welcome=label("♛  Bem-vindo, guerreiro!\\nEscolha uma opção abaixo e personalize sua experiência.",15,Color.WHITE,true);card(welcome);
            card(btn("▶  ABRIR FREE FIRE",this::openGame));
            card(btn("🎯  GERADOR DE SENSIBILIDADE",()->page("Sensibilidade")));
            card(btn("📱  CONFIGURAÇÕES DPI",()->page("Configurações DPI")));
            card(btn("🪟  PAINEL FLUTUANTE",()->page("Painel Flutuante")));
            card(btn("🎯  PROXY AIMBOT  •  APENAS VISUAL",()->page("Proxy Aimbot")));
            card(btn("👕  GALERIA DE SKINS",()->page("Skins")));
            card(btn("🔎  CONSULTAR ID",()->page("Consultar ID")));
        } else if(p.equals("Sensibilidade")){
            card(label("🎯  GERADOR DE SENSIBILIDADE\\nSugestões para personalizar seu estilo de jogo.",16,Color.WHITE,true));
            String[] ls={"Geral","Ponto Vermelho","Mira 2x","Mira 4x","Mira AWM"};int[] vals={95,90,85,80,75};
            for(int i=0;i<ls.length;i++){LinearLayout c=vertical();c.addView(label(ls[i]+"     "+vals[i],14,Color.WHITE,true));SeekBar s=new SeekBar(this);s.setMax(200);s.setProgress(vals[i]);s.setProgressTintList(android.content.res.ColorStateList.valueOf(red));c.addView(s);card(c);}
            card(btn("⚡  GERAR SUGESTÃO",()->new AlertDialog.Builder(this).setTitle("Sugestão pronta").setMessage("Use estes valores como ponto de partida e ajuste conforme sua preferência.").setPositiveButton("OK",null).show()));
        } else if(p.equals("Configurações DPI")){
            card(label("📱  CONFIGURAÇÕES DPI",17,Color.WHITE,true));EditText e=new EditText(this);e.setSingleLine(true);e.setHint("DPI manual (ex.: 480)");e.setInputType(2);e.setTextColor(Color.WHITE);card(e);
            card(btn("SALVAR VALOR",()->new AlertDialog.Builder(this).setMessage("Valor anotado nesta tela. O app não altera diretamente o DPI do sistema.").setPositiveButton("OK",null).show()));
            card(label("Cores automáticas",16,Color.WHITE,true));String[] ns={"Azul","Verde","Vermelho","Preto","Amarelo"};
            for(int i=0;i<ns.length;i++){final int j=i;card(btn("●  "+ns[i],()->{red=colors[j];page("Configurações DPI");}));}
            card(btn("⚙  ABRIR CONFIGURAÇÕES DO ANDROID",()->startActivity(new Intent(Settings.ACTION_SETTINGS))));
        } else if(p.equals("Painel Flutuante")){
            card(label("🪟  PAINEL FLUTUANTE",17,Color.WHITE,true));card(label("Permite configurar a permissão para aparecer sobre outros aplicativos.",14,Color.LTGRAY,false));
            card(btn("CONCEDER PERMISSÃO",()->{if(!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));else new AlertDialog.Builder(this).setMessage("A permissão já está concedida. A janela flutuante real será implementada numa versão futura.").setPositiveButton("OK",null).show();}));
        } else if(p.equals("Proxy Aimbot")){
            card(label("🔥 PROXY AIMBOT\\nAPENAS VISUAL — SEM TRAPAÇAS FUNCIONAIS",18,red,true));
            for(String s:new String[]{"HUD personalizado (visual)","Mira de demonstração","Animações de interface","Efeitos de destaque"}){CheckBox c=new CheckBox(this);c.setText(s);c.setTextColor(Color.WHITE);c.setButtonTintList(android.content.res.ColorStateList.valueOf(red));card(c);}
            card(label("Esta seção é apenas visual e não interage com o jogo.",14,Color.LTGRAY,false));
        } else if(p.equals("Skins")){
            card(label("👕  GALERIA DE SKINS",18,Color.WHITE,true));card(label("As opções abaixo são cartões demonstrativos; imagens reais precisam ser adicionadas ao projeto.",13,Color.LTGRAY,false));
            for(String s:new String[]{"Alok","Kelly","Hayato","Chrono","Moco","Rafael","Caroline","Antonio","Luna"})card(btn("🔥  "+s+"  •  VER PERSONAGEM",()->new AlertDialog.Builder(this).setTitle(s).setMessage("A imagem do personagem será exibida quando os recursos de imagem forem adicionados.").setPositiveButton("OK",null).show()));
        } else if(p.equals("Consultar ID")){
            card(label("🔎  CONSULTAR ID DO JOGADOR",17,Color.WHITE,true));EditText id=new EditText(this);id.setSingleLine(true);id.setHint("Digite o ID do jogador");id.setTextColor(Color.WHITE);card(id);
            card(btn("⌕  PESQUISAR",()->new AlertDialog.Builder(this).setTitle("Consulta de ID").setMessage("Não há API oficial conectada nesta versão. Para evitar dados inventados, nenhuma informação será exibida sem uma fonte legítima.").setPositiveButton("OK",null).show()));
            card(label("Nome: —\\nNível: —\\nPatente: —\\nJogos: —\\nÚltimo acesso: —",14,Color.LTGRAY,false));
        } else {
            card(label("🎨  PERSONALIZAÇÃO",18,Color.WHITE,true));String[] ns={"Azul","Verde","Vermelho","Preto","Amarelo"};
            for(int i=0;i<ns.length;i++){final int j=i;card(btn("●  "+ns[i],()->{red=colors[j];page("Mais");}));}
            card(btn("⚙  CONFIGURAÇÕES DO ANDROID",()->startActivity(new Intent(Settings.ACTION_SETTINGS))));
            card(label("Painel feito por Manaces • versão 2.0",13,Color.LTGRAY,false));
        }
    }
    void openGame(){
        Intent i=getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if(i==null)i=getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
        if(i!=null)startActivity(i);else new AlertDialog.Builder(this).setMessage("Free Fire não encontrado. Instale o jogo pela loja oficial e tente novamente.").setPositiveButton("OK",null).show();
    }
}
