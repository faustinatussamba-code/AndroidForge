# FF Launcher (projeto Android)

Projeto simples para abrir o Free Fire instalado e selecionar um arquivo local usando o seletor oficial do Android.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `FF_Launcher_Projeto` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um celular Android com depuração USB ativada ou crie um emulador.
5. Use **Run** para instalar e testar.

## Gerar APK
No Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Observações
- O app procura as versões com pacote `com.dts.freefireth` e `com.dts.freefiremax`. A disponibilidade depende da versão/região instalada.
- A seleção de arquivo apenas mostra que um arquivo foi escolhido; não modifica nem injeta dados no Free Fire.
- Não inclui aapt/Gradle Wrapper. O Android Studio pode abrir o projeto e configurar o Gradle, ou você pode adicionar um wrapper compatível pelo próprio Android Studio.
- Não pede permissão de armazenamento ampla nem acesso à internet; o seletor de documentos do Android concede acesso ao arquivo escolhido.
