package com.example.fflauncher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var selectedFileLabel: TextView? = null
    private val pickFileRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(18, 18, 22))
        }

        val title = TextView(this).apply {
            text = "FF LAUNCHER"
            textSize = 28f
            setTextColor(Color.rgb(255, 65, 65))
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Abra o Free Fire e escolha um arquivo do seu dispositivo."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 24)
        }
        root.addView(subtitle, matchWrap())

        val openButton = makeButton("ABRIR FREE FIRE")
        openButton.setOnClickListener { openFreeFire() }
        root.addView(openButton, matchWrap())

        val chooseButton = makeButton("SELECIONAR ARQUIVO")
        chooseButton.setOnClickListener { chooseFile() }
        val chooseParams = matchWrap()
        chooseParams.topMargin = 14
        root.addView(chooseButton, chooseParams)

        selectedFileLabel = TextView(this).apply {
            text = "Nenhum arquivo selecionado"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        root.addView(selectedFileLabel, matchWrap())

        val note = TextView(this).apply {
            text = "Nota: selecionar um arquivo não o injeta no jogo. Use apenas arquivos confiáveis."
            textSize = 12f
            setTextColor(Color.rgb(180, 180, 180))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(note, matchWrap())

        setContentView(root)
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 15f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(190, 35, 45))
        isAllCaps = false
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun openFreeFire() {
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (packageName in packages) {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                startActivity(launchIntent)
                return
            }
        }
        Toast.makeText(
            this,
            "Free Fire não encontrado. Instale o jogo oficial e tente novamente.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, pickFileRequest)
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFileRequest && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                val displayName = uri.lastPathSegment ?: "Arquivo selecionado"
                selectedFileLabel?.text = "Selecionado:\n$displayName"
                Toast.makeText(this, "Arquivo selecionado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
