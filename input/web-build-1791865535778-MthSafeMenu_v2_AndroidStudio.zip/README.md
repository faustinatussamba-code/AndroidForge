# Mth Safe Menu 2.0

Projeto Android Studio reconstruído de forma independente a partir da ideia visual/funcional geral do menu analisado.

Abra a pasta no Android Studio e execute a sincronização do Gradle. Depois use **Build > Build APK(s)**.

A versão segura não modifica, injeta, monitora ou tenta contornar mecanismos do Free Fire.
