package com.mth.safe.menu;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

public class MainActivity extends Activity {
    int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView label(String s, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(Color.WHITE);
        v.setTextSize(size);
        v.setTypeface(null, bold ? 1 : 0);
        v.setPadding(dp(12), dp(8), dp(12), dp(8));
        return v;
    }

    Button item(String title, String description) {
        Button b = new Button(this);
        b.setText(title + "\n" + description);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        return b;
    }

    void dialog(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(14));
        root.setBackgroundColor(Color.rgb(18,18,18));

        TextView title = label("MTH SAFE MENU", 25, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = label("Menu de utilidades • versão independente", 14, false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        Space gap = new Space(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, dp(12)));

        Button check = item("VERIFICAÇÃO", "Conferir o que este aplicativo pode fazer");
        check.setOnClickListener(v -> dialog("Verificação",
                "✓ Sem permissões especiais\n✓ Sem acesso ao Free Fire\n✓ Sem injeção ou alteração de memória\n✓ Sem proxy/VPN para o jogo\n✓ Sem anti-ban ou bypass"));
        root.addView(check, new LinearLayout.LayoutParams(-1, dp(70)));

        Button local = item("ARQUIVOS LOCAIS", "Demonstração sem acessar arquivos do jogo");
        local.setOnClickListener(v -> dialog("Demonstração segura",
                "As funções de copiar/apagar/instalar presentes em menus modificadores não foram incluídas.\n\nEsta tela é apenas informativa e não toca nos dados de outros aplicativos."));
        root.addView(local, new LinearLayout.LayoutParams(-1, dp(70)));

        Button performance = item("DESEMPENHO", "Checklist básico do aparelho");
        performance.setOnClickListener(v -> dialog("Checklist",
                "• Feche aplicativos em segundo plano quando necessário\n• Mantenha armazenamento livre\n• Evite aplicativos que modifiquem jogos\n• Se houver travamentos, reinicie o aparelho\n• Prefira a versão oficial do jogo"));
        root.addView(performance, new LinearLayout.LayoutParams(-1, dp(70)));

        Button android = item("CONFIGURAÇÕES", "Abrir configurações do Android");
        android.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_SETTINGS)));
        root.addView(android, new LinearLayout.LayoutParams(-1, dp(70)));

        Button about = item("SOBRE", "Como esta versão foi reconstruída");
        about.setOnClickListener(v -> dialog("Mth Safe Menu 2.0",
                "Reconstrução independente baseada somente na ideia de interface do APK analisado. O projeto não reutiliza a lógica nativa de segurança/proxy nem qualquer função de modificação do jogo."));
        root.addView(about, new LinearLayout.LayoutParams(-1, dp(70)));

        TextView footer = label("Aplicativo independente • sem integração com Free Fire", 12, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(12);
        root.addView(footer, fp);

        setContentView(root);
    }
}
