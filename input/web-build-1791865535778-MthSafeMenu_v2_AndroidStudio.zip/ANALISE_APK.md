# Análise do APK original

Arquivo analisado: `Proxy Mth Team v25 Menu.apk` (extraído do ZIP enviado).

## Estrutura observada
- APK Android baseado em React Native/Expo.
- `assets/index.android.bundle`.
- Bibliotecas nativas ARM64, incluindo `libmthsecurity.so`.
- A biblioteca nativa expõe símbolos/strings como `nativeDeriveDeviceId`, `nativeValidateSignature` e `nativeValidateAuthResult`.
- Há strings relacionadas a proxy/rede nas bibliotecas, além de referências de autenticação.

## Por que não reutilizar a lógica original
O APK contém componentes que não são necessários para um menu de utilidades e que podem interagir com rede, autenticação ou outros aplicativos. Como o objetivo é uma versão segura, esta reconstrução não copia essas partes.

## Funções deliberadamente removidas
- acesso à pasta/pacote do Free Fire;
- copiar/apagar/instalar arquivos do jogo;
- injeção ou alteração de memória;
- proxy/VPN para interferir no jogo;
- anti-ban/bypass/anti-cheat;
- execução de código sobre outro aplicativo;
- coleta ou autenticação remota.

## Resultado
O projeto é uma reconstrução independente da interface/ideia de menu, compilável no Android Studio, com funções locais e sem integração com o Free Fire.
