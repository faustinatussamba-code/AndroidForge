# ShadowBoost Safe — projeto-base Android Studio

Este projeto é uma base segura de interface para recomendações de estabilidade. Ele **não** é uma versão modificada do APK ShadowBoost original.

## O que faz
- Mostra recomendações de estabilidade para jogos.
- Oferece um checklist de teste comparativo.
- Não altera os arquivos do Free Fire.
- Não executa comandos ADB ou comandos `cmd game`.
- Não usa Shizuku, acessibilidade, VPN, root ou permissões especiais.
- Não promete aumentar FPS: o resultado depende do aparelho, temperatura, jogo e opções disponíveis.

## Abrir no Android Studio
1. Extraia o ZIP.
2. No Android Studio, escolha **Open** e selecione a pasta `ShadowBoostSafe-AndroidStudio`.
3. Aguarde a sincronização do Gradle.
4. Se o Android Studio solicitar instalar o SDK Android 35, aceite pelo SDK Manager.
5. Execute em um aparelho de teste ou emulador.

## Limitações
Este é código-fonte inicial, não um APK compilado. A compilação pode exigir conexão à internet para baixar Gradle e dependências do Android Gradle Plugin. Para alterar o APK original seria necessário decompilar e entender seu código; não se deve assumir que este projeto reproduz suas funções internas.
