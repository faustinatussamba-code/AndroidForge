package br.com.shadowboost.safe

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(17, 22, 32)
    private val panel = Color.rgb(29, 37, 51)
    private val accent = Color.rgb(94, 184, 255)
    private val white = Color.rgb(242, 246, 252)
    private val muted = Color.rgb(183, 194, 209)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("SHADOWBOOST SAFE", 25, accent, true))
        root.addView(text("Base segura de desempenho • Android", 14, muted, false))
        root.addView(space(18))
        root.addView(card(
            "Modo seguro ativado",
            "Esta versão não altera os arquivos do Free Fire, não força comandos ADB, não usa Shizuku e não pede permissões especiais. As opções abaixo são orientações — não modificam o sistema automaticamente."
        ))
        root.addView(space(14))
        root.addView(text("Checklist para estabilidade", 19, white, true))
        root.addView(space(8))
        root.addView(card(
            "1. Dentro do Free Fire",
            "• Use gráficos Suave.\n• Desative sombras se a opção estiver disponível.\n• Escolha uma taxa de FPS estável que o jogo ofereça.\n• Teste uma partida de treino antes de comparar."
        ))
        root.addView(space(10))
        root.addView(card(
            "2. No Samsung Galaxy A07",
            "• Ative Economia de energia somente se precisar prolongar a bateria; ela pode reduzir o desempenho.\n• Feche gravações de tela e apps pesados em segundo plano.\n• Evite jogar enquanto o aparelho estiver muito quente.\n• Mantenha espaço livre e atualizações oficiais em dia."
        ))
        root.addView(space(10))
        root.addView(card(
            "3. Escala de renderização",
            "Recomendação inicial: manter o padrão do sistema. Uma escala menor pode aliviar a GPU em alguns aparelhos, mas deixa a imagem menos nítida e não garante FPS maior. Esta versão não aplica escala automaticamente."
        ))
        root.addView(space(14))
        root.addView(text("Ferramentas de teste", 19, white, true))
        root.addView(space(8))
        root.addView(actionButton("Mostrar plano de teste") {
            showToast("Teste: jogue 10 minutos com as mesmas opções, observe travamentos e temperatura; depois mude apenas uma opção e compare.")
        })
        root.addView(space(8))
        root.addView(actionButton("Restaurar recomendações padrão") {
            showToast("Recomendações padrão: escala do sistema, sem comandos forçados e sem permissões especiais.")
        })
        root.addView(space(16))
        root.addView(text(
            "Aviso: este projeto é uma base segura de interface e recomendações, não uma modificação do APK original. Ele não promete aumentar FPS nem melhorar a mira.",
            13, muted, false
        ))
    }

    private fun card(title: String, body: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(panel)
            addView(text(title, 16, white, true))
            addView(space(6))
            addView(text(body, 14, muted, false))
        }
    }

    private fun actionButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(43, 109, 165))
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
            )
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView {
        return TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.START
            setLineSpacing(dp(2).toFloat(), 1.0f)
        }
    }

    private fun space(height: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
