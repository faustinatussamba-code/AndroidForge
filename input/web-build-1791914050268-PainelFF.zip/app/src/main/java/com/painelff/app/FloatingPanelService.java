package com.painelff.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private LinearLayout panel;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(10, 8, 10, 8);
        panel.setBackgroundColor(0xEE171717);

        TextView title = new TextView(this);
        title.setText("🔥 FF");
        title.setTextColor(0xFFFF5252);
        title.setTextSize(18);
        panel.addView(title);

        Button sens = new Button(this);
        sens.setText("Sensibilidade");
        sens.setOnClickListener(v -> title.setText("Geral 95 • Red Dot 90"));
        panel.addView(sens);

        Button visual = new Button(this);
        visual.setText("XIT (visual)");
        visual.setOnClickListener(v -> title.setText("Somente visual"));
        panel.addView(visual);

        Button close = new Button(this);
        close.setText("Fechar");
        close.setOnClickListener(v -> stopSelf());
        panel.addView(close);

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END;
        p.x = 16; p.y = 80;
        wm.addView(panel, p);
    }

    @Override public void onDestroy() {
        if (panel != null && panel.getParent() != null) wm.removeView(panel);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
