package com.painelff.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root;
    private int[] colors = {0xFF1565C0, 0xFF2E7D32, 0xFFC62828, 0xFF111111, 0xFFF9A825};
    private int colorIndex = 0;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(0xFF111111);
        setContentView(root);
        buildUi();
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 7, 0, 7);
        root.addView(b, lp);
        return b;
    }

    private void buildUi() {
        root.removeAllViews();
        TextView title = new TextView(this);
        title.setText("🔥 PAINEL FF");
        title.setTextSize(28);
        title.setTextColor(0xFFFF5252);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Sensibilidade • Treino • DPI");
        subtitle.setTextColor(-1);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        button("Abrir Free Fire", this::openFreeFire);
        button("Gerar sensibilidade", () -> {
            String msg = "Sugestão inicial: Geral 95 • Ponto vermelho 90 • 2x 85 • 4x 75 • AWM 50. Ajuste no treino.";
            new android.app.AlertDialog.Builder(this).setTitle("Sensibilidade sugerida")
                .setMessage(msg).setPositiveButton("OK", null).show();
        });
        button("Painel flutuante", this::startFloating);
        button("DPI manual (Shizuku)", () -> new android.app.AlertDialog.Builder(this)
            .setTitle("DPI manual")
            .setMessage("Esta versão mostra a função como preparação visual. Para alterar DPI via Shizuku, é necessário integrar e testar a API do Shizuku e conceder autorização.")
            .setPositiveButton("Entendi", null).show());
        button("ATIVAR XIT (visual)", () -> Toast.makeText(this,
            "Demonstração visual: nenhuma alteração no jogo foi feita.", Toast.LENGTH_LONG).show());
        button("Mudar cor do app", () -> {
            colorIndex = (colorIndex + 1) % colors.length;
            root.setBackgroundColor(colors[colorIndex]);
        });
        button("Restaurar cor padrão", () -> {
            colorIndex = 0;
            root.setBackgroundColor(0xFF111111);
        });
        TextView note = new TextView(this);
        note.setText("\nO painel não modifica arquivos nem memória do Free Fire.");
        note.setTextColor(0xFFCCCCCC);
        note.setGravity(Gravity.CENTER);
        root.addView(note);
    }

    private void openFreeFire() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if (launch == null) {
            Toast.makeText(this, "Free Fire normal não encontrado. Instale a versão normal.", Toast.LENGTH_LONG).show();
        } else startActivity(launch);
    }

    private void startFloating() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivity(i);
            Toast.makeText(this, "Autorize 'sobrepor a outros apps' e toque novamente.", Toast.LENGTH_LONG).show();
            return;
        }
        startService(new Intent(this, FloatingPanelService.class));
        Toast.makeText(this, "Painel flutuante iniciado.", Toast.LENGTH_SHORT).show();
    }
}
