# Painel FF (projeto Android)

Projeto inicial Android nativo em Java para abrir no Android Studio.

## Incluído
- Botão para abrir Free Fire normal (`com.dts.freefireth`)
- Sugestão inicial de sensibilidade
- Solicitação de permissão de sobreposição e painel flutuante
- Botão de demonstração “XIT (visual)” que não altera o jogo
- Alternância manual das cores do app

## Importante
- A função DPI/Shizuku ainda é apenas uma tela informativa; não altera o DPI.
- Não há APK pré-compilado neste ZIP. Abra no Android Studio e compile com Gradle/Android SDK instalado.
- Requer Android Studio recente e SDK Android 35.
