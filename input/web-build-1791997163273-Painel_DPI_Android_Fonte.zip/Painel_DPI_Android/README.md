# Painel DPI para Android

Projeto-fonte Android Studio em Kotlin, com painel preto/roxo e alteração de densidade via comando `wm density`, executado por meio do Shizuku.

## Requisitos
- Android Studio recente (JDK 17).
- Internet para baixar dependências Gradle na primeira compilação.
- App Shizuku instalado e iniciado. Página oficial: https://shizuku.rikka.app/
- Autorizar o Painel DPI dentro do Shizuku.
- Em aparelhos sem root, o Shizuku normalmente precisa ser iniciado por Depuração sem fio/ADB. A disponibilidade varia conforme a versão e fabricante.

## Como compilar
1. Extraia o ZIP.
2. Abra a pasta `Painel_DPI_Android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale o SDK Android 35 e use JDK 17.
5. Use **Build > Build APK(s)**.

## Como usar
1. Inicie o Shizuku conforme as instruções oficiais dele.
2. Abra o Painel DPI e conceda a permissão solicitada.
3. Anote a densidade atual usando **Consultar DPI atual**.
4. Digite a DPI desejada e toque em **Aplicar DPI**.
5. Para desfazer a alteração, toque em **Restaurar densidade padrão**.

## Importante
- A DPI/densidade afeta a interface inteira do Android, não só o Free Fire.
- Não altera os arquivos do Free Fire, não injeta código no jogo e não promete FPS maior.
- Valores extremos podem deixar textos e botões difíceis de usar. Anote a configuração original antes de mudar.
- O projeto é código-fonte; não inclui APK pré-compilado.
- O projeto depende da API do Shizuku e de acesso à internet na primeira compilação.
