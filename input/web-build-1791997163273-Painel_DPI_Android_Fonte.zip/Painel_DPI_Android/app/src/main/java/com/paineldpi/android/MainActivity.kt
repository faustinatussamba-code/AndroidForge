package com.paineldpi.android

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private val purple = Color.rgb(176, 42, 208)
    private val bg = Color.rgb(17, 17, 17)
    private val card = Color.rgb(34, 34, 34)
    private val requestCode = 4201
    private lateinit var status: TextView
    private lateinit var densityInput: EditText
    private lateinit var output: TextView

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == requestCode) {
            if (result == PackageManagerCompat.PERMISSION_GRANTED) {
                status.text = "Shizuku autorizado. Pode aplicar a DPI."
                status.setTextColor(Color.GREEN)
            } else {
                status.text = "Permissão Shizuku negada."
                status.setTextColor(Color.RED)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        buildUi()
        refreshStatus()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(Color.rgb(8, 8, 8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(purple, 18)
        }
        val title = TextView(this).apply {
            text = "Painel DPI"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val tag = TextView(this).apply {
            text = "ANDROID"
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(Color.rgb(80, 20, 96), 20)
        }
        header.addView(tag)
        root.addView(header)

        val subtitle = TextView(this).apply {
            text = "Ajustes do sistema • sem modificar o Free Fire"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(dp(4), dp(10), dp(4), dp(12))
        }
        root.addView(subtitle)

        val authCard = panel()
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.YELLOW)
        }
        authCard.addView(status)
        authCard.addView(button("Abrir Shizuku / verificar autorização") {
            try {
                startActivity(Intent("moe.shizuku.manager.intent.action.MAIN"))
            } catch (_: Exception) {
                openUrl("https://shizuku.rikka.app/")
            }
        })
        authCard.addView(button("Solicitar permissão") { requestShizukuPermission() })
        root.addView(authCard)

        val dpiCard = panel()
        dpiCard.addView(label("DPI / densidade da tela"))
        dpiCard.addView(label("Digite um valor. Ex.: use o valor original anotado antes de alterar."))
        densityInput = EditText(this).apply {
            hint = "Ex.: 440"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 18f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(48, 48, 48), 10)
        }
        dpiCard.addView(densityInput, matchWidth())
        dpiCard.addView(button("Aplicar DPI") {
            val value = densityInput.text.toString().trim().toIntOrNull()
            if (value == null || value !in 100..1000) {
                toast("Digite uma DPI entre 100 e 1000.")
            } else {
                runWmCommand("wm density $value", "DPI aplicada: $value")
            }
        })
        dpiCard.addView(button("Restaurar densidade padrão") {
            runWmCommand("wm density reset", "Densidade padrão restaurada.")
        })
        dpiCard.addView(button("Consultar DPI atual") {
            runWmCommand("wm density", null)
        })
        root.addView(dpiCard)

        val infoCard = panel()
        infoCard.addView(label("FPS e gráficos"))
        infoCard.addView(label("Este painel não altera FPS ou gráficos dentro do jogo. Essas opções dependem do próprio Free Fire e do sistema."))
        infoCard.addView(label("A alteração de densidade afeta todo o Android, não apenas o jogo."))
        root.addView(infoCard)

        output = TextView(this).apply {
            text = "Resultado dos comandos aparecerá aqui."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(dp(4), dp(10), dp(4), dp(4))
        }
        root.addView(output)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun panel(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(card, 16)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = dp(10)
            layoutParams = params
        }
    }

    private fun label(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.WHITE)
        setPadding(0, dp(3), 0, dp(7))
    }

    private fun button(textValue: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = textValue
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(purple, 12)
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(-1, -2)
            p.topMargin = dp(6)
            layoutParams = p
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun matchWidth() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun refreshStatus() {
        val running = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        status.text = if (!running) {
            "Shizuku não está ativo. Inicie o Shizuku primeiro."
        } else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            "Shizuku ativo e autorizado."
        } else {
            "Shizuku ativo, mas falta autorização para este app."
        }
    }

    private fun requestShizukuPermission() {
        if (!Shizuku.pingBinder()) {
            toast("Inicie o Shizuku e tente novamente.")
            return
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            refreshStatus()
            toast("Permissão já concedida.")
        } else {
            Shizuku.requestPermission(requestCode)
        }
    }

    private fun runWmCommand(command: String, successMessage: String?) {
        if (!Shizuku.pingBinder()) {
            toast("Shizuku não está ativo.")
            refreshStatus()
            return
        }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            toast("Conceda a permissão Shizuku primeiro.")
            requestShizukuPermission()
            return
        }
        Thread {
            try {
                val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
                val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
                val exit = process.waitFor()
                runOnUiThread {
                    val result = buildString {
                        if (!successMessage.isNullOrBlank() && exit == 0) append("$successMessage\n")
                        append("Comando: $command\nCódigo: $exit\n")
                        if (stdout.isNotBlank()) append(stdout.trim())
                        if (stderr.isNotBlank()) append("\n${stderr.trim()}")
                        if (stdout.isBlank() && stderr.isBlank() && exit == 0) append("Concluído.")
                    }
                    output.text = result
                    toast(if (exit == 0) "Comando concluído." else "O comando falhou. Veja o resultado.")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    output.text = "Erro: ${e.message ?: "não foi possível executar"}"
                    toast("Falha ao executar comando.")
                }
            }
        }.start()
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private object PackageManagerCompat {
        const val PERMISSION_GRANTED = android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}
