package com.ffa07;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 1001;
    private TextView selectedFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        root.setBackgroundColor(0xFF101820);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("FF A07");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Ferramentas simples para seu Galaxy A07");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFFB9C7D3);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(8), 0, dp(22));
        root.addView(subtitle, matchWrap());

        addButton(root, "Abrir Free Fire", v -> openGame("com.dts.freefireth"));
        addButton(root, "Abrir Free Fire MAX", v -> openGame("com.dts.freefiremax"));
        addButton(root, "Selecionar arquivo", v -> chooseFile());

        selectedFile = new TextView(this);
        selectedFile.setText("Nenhum arquivo selecionado.");
        selectedFile.setTextSize(14);
        selectedFile.setTextColor(0xFFFFFFFF);
        selectedFile.setPadding(dp(4), dp(10), dp(4), dp(18));
        root.addView(selectedFile, matchWrap());

        TextView section = new TextView(this);
        section.setText("Dicas de sensibilidade");
        section.setTextSize(20);
        section.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        section.setTextColor(0xFFFFFFFF);
        section.setPadding(0, dp(8), 0, dp(8));
        root.addView(section, matchWrap());

        TextView tips = new TextView(this);
        tips.setText("• Comece com a sensibilidade padrão e ajuste aos poucos.\n"
                + "• Teste cada mudança no campo de treinamento.\n"
                + "• Se a mira passar da cabeça, reduza um pouco a sensibilidade Geral.\n"
                + "• As opções podem variar conforme a versão do jogo.");
        tips.setTextSize(15);
        tips.setLineSpacing(dp(5), 1.0f);
        tips.setTextColor(0xFFE5EDF3);
        root.addView(tips, matchWrap());

        TextView note = new TextView(this);
        note.setText("\nEste app não injeta arquivos no jogo, não altera sua memória e não modifica o Free Fire. "
                + "O seletor de arquivos apenas permite escolher um arquivo e mostrar seu nome.");
        note.setTextSize(12);
        note.setTextColor(0xFF9EADB9);
        root.addView(note, matchWrap());

        setContentView(scroll);
    }

    private void openGame(String packageName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) {
            startActivity(launch);
        } else {
            Toast.makeText(this, "Esse jogo não está instalado (ou usa outro pacote).", Toast.LENGTH_LONG).show();
        }
    }

    private void chooseFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try {
            startActivityForResult(intent, PICK_FILE);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Não foi possível abrir o seletor de arquivos.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            String name = "Arquivo selecionado";
            Cursor cursor = null;
            try {
                cursor = getContentResolver().query(uri, null, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index >= 0) name = cursor.getString(index);
                }
            } catch (Exception ignored) {
            } finally {
                if (cursor != null) cursor.close();
            }
            selectedFile.setText("Selecionado: " + name + "\nURI: " + uri);
        }
    }

    private void addButton(LinearLayout root, String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(16);
        button.setOnClickListener(listener);
        LinearLayout.LayoutParams params = matchWrap();
        params.bottomMargin = dp(10);
        root.addView(button, params);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
