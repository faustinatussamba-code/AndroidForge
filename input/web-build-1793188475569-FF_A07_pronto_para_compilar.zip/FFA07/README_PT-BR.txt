FF A07 — projeto Android para compilar APK

O que inclui:
- Projeto Android nativo em Java.
- Botões para abrir Free Fire ou Free Fire MAX se estiverem instalados.
- Seletor Android para escolher um arquivo e mostrar o nome.
- Dicas básicas de sensibilidade.
- Sem VPN, sem integração com IA e sem permissão de internet.
- Não injeta arquivos no jogo nem altera memória/arquivos do Free Fire.

Como gerar o APK:
1. Extraia o ZIP.
2. Abra a pasta FFA07 no Android Studio.
3. Aguarde a sincronização do Gradle (é necessária conexão à internet na primeira vez para baixar ferramentas).
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug normalmente ficará em app/build/outputs/apk/debug/app-debug.apk.

Requisitos:
- Android Studio atualizado.
- JDK 17 (geralmente incluído no Android Studio).
- Android SDK Platform 35 instalado.

Observação:
O projeto não inclui o Gradle Wrapper. Abra pelo Android Studio, que poderá configurar/usar o Gradle local.
O pacote do Free Fire pode variar por região/versão; se o botão não abrir o jogo, abra-o normalmente pelo celular.
